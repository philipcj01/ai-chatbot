import ChatBot from './components/ChatBot'
import Header from './components/Header'
import Footer from './components/Footer'
import './App.css'
import './components/Footer.css'

function App() {
  return (
    <div className="app-container bg-gray-50">
      <Header />
      
      <main className="app-main-content">
        <div className="app-content-wrapper">
          <div className="w-full max-w-4xl">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-2">
                Interactive AI Assistant
              </h2>
              <p className="text-gray-600">
                Start a conversation with our intelligent chatbot
              </p>
            </div>
            <ChatBot />
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  )
}

export default App
