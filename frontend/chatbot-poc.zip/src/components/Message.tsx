import React from 'react';
import { Bot, User } from 'lucide-react';
import type { ChatMessage } from '../types/chat';
import './Message.css';

interface MessageProps {
  message: ChatMessage;
}

const Message: React.FC<MessageProps> = ({ message }) => {
  const isBot = message.sender === 'bot';

  return (
    <div className={`message-wrapper ${isBot ? 'message-bot' : 'message-user'}`}>
      <div className={`message-content ${isBot ? 'message-bot' : 'message-user'}`}>
        {/* Avatar */}
        <div className={`message-avatar ${isBot ? 'avatar-bot' : 'avatar-user'}`}>
          {isBot ? (
            <Bot className="w-4 h-4 text-white" />
          ) : (
            <User className="w-4 h-4 text-white" />
          )}
        </div>

        {/* Message Bubble */}
        <div className="message-bubble-container">
          <div className={`message-bubble ${isBot ? 'bubble-bot' : 'bubble-user'}`}>
            <p className="message-text">{message.text}</p>
          </div>
          
          {/* Timestamp */}
          <p className={`message-timestamp ${isBot ? 'timestamp-bot' : 'timestamp-user'}`}>
            {message.timestamp.toLocaleTimeString([], { 
              hour: '2-digit', 
              minute: '2-digit' 
            })}
          </p>
        </div>
      </div>
    </div>
  );
};

export default Message;