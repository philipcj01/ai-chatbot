import React from 'react';
import { Bot, Menu, X } from 'lucide-react';
import './Header.css';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  return (
    <>
      <header className="header-container">
        <div className="header-content">
          <div className="header-main-row">
            {/* Logo and Brand */}
            <div className="header-logo-section">
              <div className="header-logo-icon">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div className="header-logo-text">
                <h1>AI Chatbot</h1>
                <p>Proof of Concept</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="header-desktop-nav">
              <a href="#" className="header-nav-link">
                Home
              </a>
              <a href="#" className="header-nav-link">
                About
              </a>
              <a href="#" className="header-nav-link">
                Documentation
              </a>
              <button className="header-get-started-btn">
                Get Started
              </button>
            </nav>

            {/* Mobile Menu Button */}
            <button
              className="header-mobile-btn"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <X className="w-6 h-6 text-white" />
              ) : (
                <Menu className="w-6 h-6 text-white" />
              )}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="header-mobile-nav">
              <nav className="header-mobile-menu">
                <a href="#" className="header-mobile-link">
                  Home
                </a>
                <a href="#" className="header-mobile-link">
                  About
                </a>
                <a href="#" className="header-mobile-link">
                  Documentation
                </a>
                <button className="header-mobile-get-started">
                  Get Started
                </button>
              </nav>
            </div>
          )}
        </div>
      </header>
      {/* Strong visual divider with dedicated CSS */}
      <div className="header-divider-main"></div>
      <div className="header-divider-accent"></div>
    </>
  );
};

export default Header;