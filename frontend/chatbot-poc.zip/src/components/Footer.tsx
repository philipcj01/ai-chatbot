import React from 'react';
import { Bot, Github, Twitter, Linkedin, Mail } from 'lucide-react';
import './Footer.css';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <>
      {/* Semi-transparent divider above footer */}
      <div className="footer-divider"></div>
      <footer className="footer-container">
        <div className="footer-content">
          <div className="footer-main-row">
            {/* Brand and Copyright */}
            <div className="footer-brand-section">
              <div className="footer-logo-icon">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="footer-brand-text">
                <p className="footer-brand-title">AI Chatbot POC</p>
                <p className="footer-brand-copyright">© {currentYear} All rights reserved</p>
              </div>
            </div>

            {/* Social Links */}
            <div className="footer-social-section">
              <div className="footer-social-links">
                <a href="#" className="footer-social-link">
                  <Github className="w-4 h-4" />
                </a>
                <a href="#" className="footer-social-link">
                  <Twitter className="w-4 h-4" />
                </a>
                <a href="#" className="footer-social-link">
                  <Linkedin className="w-4 h-4" />
                </a>
                <a href="#" className="footer-social-link">
                  <Mail className="w-4 h-4" />
                </a>
              </div>
              <div className="footer-divider-vertical"></div>
              <span className="footer-tech-text">Made with React & TypeScript</span>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
};

export default Footer;