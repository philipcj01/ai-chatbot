import axios from "axios";

// Mock responses for demonstration - replace with your actual API endpoint
const mockResponses = [
  "I understand your question. Let me help you with that.",
  "That's an interesting point. Here's what I think about it...",
  "I can help you with that! Here are some suggestions:",
  "Based on what you've told me, I would recommend:",
  "Let me break this down for you:",
  "That's a great question! Here's my response:",
  "I see what you mean. Let me explain this further:",
];

export const sendMessageToAPI = async (message: string): Promise<string> => {
  try {
    // For development/demo purposes, use mock responses
    if (import.meta.env.DEV || !import.meta.env.VITE_API_BASE_URL) {
      // Simulate API delay
      await new Promise((resolve) =>
        setTimeout(resolve, 1000 + Math.random() * 2000)
      );

      // Return a random mock response
      const randomResponse =
        mockResponses[Math.floor(Math.random() * mockResponses.length)];
      return `${randomResponse} You said: "${message}"`;
    }

    // Actual API call - uncomment and modify when you have a real API
    /*
    const API_CONFIG = {
      baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:3001/api',
      timeout: 10000,
    };
    
    const apiClient = axios.create(API_CONFIG);
    
    const response = await apiClient.post<APIResponse>('/chat', {
      message: message,
      timestamp: new Date().toISOString(),
    });

    if (response.data.success) {
      return response.data.message;
    } else {
      throw new Error(response.data.error || 'API request failed');
    }
    */

    // Fallback to mock response if API is not configured
    return `Echo: ${message}`;
  } catch (error) {
    console.error("Chat API Error:", error);

    if (axios.isAxiosError(error)) {
      if (error.response) {
        throw new Error(`Server error: ${error.response.status}`);
      } else if (error.request) {
        throw new Error("Network error - please check your connection");
      }
    }

    throw new Error("Failed to send message. Please try again.");
  }
};

// Additional service functions for future features
export const getChatHistory = async (): Promise<any[]> => {
  // Implement chat history retrieval
  return [];
};

export const clearChatHistory = async (): Promise<void> => {
  // Implement chat history clearing
  console.log("Chat history cleared");
};
