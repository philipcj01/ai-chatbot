import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Bot, Menu, X } from 'lucide-react';
import './Header.css';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <>
      <header className="header-container">
        <div className="header-content">
          <div className="header-main-row">
            {/* Logo and Brand */}
            <div className="header-logo-section">
              <div className="header-logo-icon">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div className="header-logo-text">
                <img 
                  src="/juhl-ai-logo.png" 
                  alt="JUHL AI" 
                  className="header-logo-image"
                />
                <p>The new era of automation</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="header-desktop-nav">
              <Link 
                to="/" 
                className={`header-nav-link ${isActive('/') ? 'active' : ''}`}
              >
                Home
              </Link>
              <Link 
                to="/documentation" 
                className={`header-nav-link ${isActive('/documentation') ? 'active' : ''}`}
              >
                Documentation
              </Link>
              <Link 
                to="/faq" 
                className={`header-nav-link ${isActive('/faq') ? 'active' : ''}`}
              >
                FAQ
              </Link>
              <Link 
                to="/get-started" 
                className="header-get-started-btn"
              >
                Get Started
              </Link>
            </nav>

            {/* Mobile Menu Button */}
            <button
              className="header-mobile-btn"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <X className="w-6 h-6 text-white" />
              ) : (
                <Menu className="w-6 h-6 text-white" />
              )}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="header-mobile-nav">
              <nav className="header-mobile-menu">
                <Link 
                  to="/" 
                  className={`header-mobile-link ${isActive('/') ? 'active' : ''}`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  Home
                </Link>
                <Link 
                  to="/documentation" 
                  className={`header-mobile-link ${isActive('/documentation') ? 'active' : ''}`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  Documentation
                </Link>
                <Link 
                  to="/faq" 
                  className={`header-mobile-link ${isActive('/faq') ? 'active' : ''}`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  FAQ
                </Link>
                <Link 
                  to="/get-started" 
                  className="header-mobile-get-started"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Get Started
                </Link>
              </nav>
            </div>
          )}
        </div>
      </header>
      {/* Strong visual divider with dedicated CSS */}
      <div className="header-divider-main"></div>
      <div className="header-divider-accent"></div>
    </>
  );
};

export default Header;