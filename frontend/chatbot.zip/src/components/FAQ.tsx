import React from 'react';
import { HelpCircle, Cloud, Workflow, Cpu, Shield, Zap, CheckCircle, Info } from 'lucide-react';
import './FAQ.css';

const FAQ: React.FC = () => {
  return (
    <div className="faq-container">
      <div className="faq-content">
        {/* Hero Section */}
        <section className="faq-hero">
          <div className="faq-hero-content">
            <HelpCircle className="faq-hero-icon" />
            <h1 className="faq-hero-title">Frequently Asked Questions</h1>
            <p className="faq-hero-subtitle">
              Everything you need to know about our AI-powered chatbot platform and its capabilities
            </p>
          </div>
        </section>

        {/* AI & Models Section */}
        <section className="faq-section">
          <h2 className="faq-section-title">
            <Cpu className="faq-icon" />
            AI Models & AWS Bedrock
          </h2>
          <div className="faq-grid">
            <div className="faq-card">
              <div className="faq-card-header">
                <Cloud className="faq-card-icon ai" />
                <h3>Which AI models can I use?</h3>
              </div>
              <p>
                Our platform supports <strong>almost every Large Language Model (LLM)</strong> available through 
                <strong> AWS Bedrock</strong>. This includes:
              </p>
              <ul className="faq-list">
                <li>Claude (Anthropic) - Multiple versions including Claude 3.5 Sonnet</li>
                <li>GPT models via Amazon Bedrock</li>
                <li>Llama 2 and Llama 3 (Meta)</li>
                <li>Titan models (Amazon)</li>
                <li>Cohere Command models</li>
                <li>AI21 Labs Jurassic models</li>
                <li>Stability AI models</li>
              </ul>
              <div className="faq-highlight">
                <Info className="w-4 h-4" />
                <span>AWS Bedrock provides serverless access to foundation models with enterprise-grade security and compliance.</span>
              </div>
            </div>

            <div className="faq-card">
              <div className="faq-card-header">
                <Shield className="faq-card-icon security" />
                <h3>How does AWS Bedrock ensure security?</h3>
              </div>
              <p>
                AWS Bedrock provides enterprise-grade security and privacy:
              </p>
              <ul className="faq-list">
                <li><strong>Data Privacy:</strong> Your data never leaves your AWS environment</li>
                <li><strong>Encryption:</strong> End-to-end encryption in transit and at rest</li>
                <li><strong>Compliance:</strong> SOC, GDPR, HIPAA compliant infrastructure</li>
                <li><strong>Access Control:</strong> Fine-grained IAM permissions</li>
                <li><strong>Audit Trails:</strong> Complete logging and monitoring</li>
              </ul>
            </div>

            <div className="faq-card">
              <div className="faq-card-header">
                <Zap className="faq-card-icon performance" />
                <h3>What are the benefits of using AWS Bedrock?</h3>
              </div>
              <ul className="faq-list">
                <li><strong>Model Agnostic:</strong> Switch between models without changing code</li>
                <li><strong>Serverless:</strong> No infrastructure management required</li>
                <li><strong>Cost Effective:</strong> Pay only for what you use</li>
                <li><strong>High Performance:</strong> Low latency and high throughput</li>
                <li><strong>Easy Integration:</strong> Simple API calls with consistent interface</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Camunda & Architecture Section */}
        <section className="faq-section">
          <h2 className="faq-section-title">
            <Workflow className="faq-icon" />
            Camunda AI Agents & Modularity
          </h2>
          <div className="faq-grid">
            <div className="faq-card">
              <div className="faq-card-header">
                <Workflow className="faq-card-icon workflow" />
                <h3>What makes our AI agents modular?</h3>
              </div>
              <p>
                Our AI agents are built using <strong>Camunda's workflow engine</strong>, which provides 
                exceptional modularity through:
              </p>
              <ul className="faq-list">
                <li><strong>BPMN Workflows:</strong> Visual process modeling with drag-and-drop simplicity</li>
                <li><strong>Service Tasks:</strong> Modular components that can be reused across workflows</li>
                <li><strong>Decision Tables:</strong> Business rules that can be modified without code changes</li>
                <li><strong>Event-Driven:</strong> Reactive architecture that responds to business events</li>
                <li><strong>Microservices Ready:</strong> Each component can run independently</li>
              </ul>
              <div className="faq-highlight">
                <CheckCircle className="w-4 h-4" />
                <span>Change business logic in minutes, not weeks. No developer required for many modifications.</span>
              </div>
            </div>

            <div className="faq-card">
              <div className="faq-card-header">
                <Cpu className="faq-card-icon ai" />
                <h3>How does the agnostic architecture work?</h3>
              </div>
              <p>
                Our platform is completely <strong>technology agnostic</strong>, meaning:
              </p>
              <ul className="faq-list">
                <li><strong>LLM Agnostic:</strong> Switch AI models based on task requirements</li>
                <li><strong>Database Agnostic:</strong> Works with any database system</li>
                <li><strong>Integration Agnostic:</strong> Connect to any API, service, or legacy system</li>
                <li><strong>Language Agnostic:</strong> Support for multiple programming languages</li>
              </ul>
            </div>

            <div className="faq-card">
              <div className="faq-card-header">
                <Zap className="faq-card-icon performance" />
                <h3>What workflows can AI agents handle?</h3>
              </div>
              <p>
                Camunda enables AI agents to orchestrate complex business processes:
              </p>
              <ul className="faq-list">
                <li><strong>Customer Onboarding:</strong> Multi-step verification and setup processes</li>
                <li><strong>Support Escalation:</strong> Intelligent routing based on issue complexity</li>
                <li><strong>Document Processing:</strong> OCR, validation, and approval workflows</li>
                <li><strong>Compliance Checking:</strong> Automated regulatory compliance verification</li>
                <li><strong>Order Processing:</strong> End-to-end order fulfillment automation</li>
                <li><strong>Data Integration:</strong> Synchronization across multiple systems</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Basic Information Section */}
        <section className="faq-section">
          <h2 className="faq-section-title">
            <Info className="faq-icon" />
            Getting Started - Basics
          </h2>
          <div className="faq-grid">
            <div className="faq-card">
              <h3>What is an AI Agent?</h3>
              <p>
                An AI agent is an intelligent software system that can:
              </p>
              <ul className="faq-list">
                <li><strong>Understand:</strong> Natural language input from users</li>
                <li><strong>Reason:</strong> Analyze context and make decisions</li>
                <li><strong>Act:</strong> Execute tasks and workflows automatically</li>
                <li><strong>Learn:</strong> Improve performance over time</li>
                <li><strong>Integrate:</strong> Work with existing business systems</li>
              </ul>
            </div>

            <div className="faq-card">
              <h3>How long does implementation take?</h3>
              <p>
                Implementation time varies based on complexity:
              </p>
              <ul className="faq-list">
                <li><strong>Basic Chatbot:</strong> 1-2 weeks</li>
                <li><strong>Customer Support Agent:</strong> 2-4 weeks</li>
                <li><strong>Complex Workflow Integration:</strong> 4-8 weeks</li>
                <li><strong>Enterprise Solution:</strong> 2-6 months</li>
              </ul>
              <div className="faq-highlight">
                <Zap className="w-4 h-4" />
                <span>Our modular approach means you can start simple and add complexity over time.</span>
              </div>
            </div>

            <div className="faq-card">
              <h3>What technical skills are required?</h3>
              <p>
                Our platform is designed for different skill levels:
              </p>
              <ul className="faq-list">
                <li><strong>Business Users:</strong> Configure workflows using visual tools</li>
                <li><strong>IT Teams:</strong> Handle integrations and advanced configurations</li>
                <li><strong>Developers:</strong> Create custom components and extensions</li>
                <li><strong>DevOps:</strong> Manage deployment and infrastructure</li>
              </ul>
            </div>

            <div className="faq-card">
              <h3>What industries benefit most?</h3>
              <ul className="faq-list">
                <li><strong>Financial Services:</strong> Customer onboarding, compliance, fraud detection</li>
                <li><strong>Healthcare:</strong> Patient support, appointment scheduling, claims processing</li>
                <li><strong>E-commerce:</strong> Customer service, order processing, returns management</li>
                <li><strong>Manufacturing:</strong> Supply chain optimization, quality control, maintenance</li>
                <li><strong>Government:</strong> Citizen services, document processing, regulatory compliance</li>
                <li><strong>Education:</strong> Student support, administrative tasks, learning assistance</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Technical Details Section */}
        <section className="faq-section">
          <h2 className="faq-section-title">
            <Shield className="faq-icon" />
            Technical Details
          </h2>
          <div className="faq-grid">
            <div className="faq-card">
              <h3>How does the platform scale?</h3>
              <ul className="faq-list">
                <li><strong>Horizontal Scaling:</strong> Add more instances as demand grows</li>
                <li><strong>Auto-scaling:</strong> Automatic resource adjustment based on load</li>
                <li><strong>Load Balancing:</strong> Distribute requests across multiple servers</li>
                <li><strong>Caching:</strong> Intelligent caching for faster response times</li>
                <li><strong>CDN Integration:</strong> Global content delivery for optimal performance</li>
              </ul>
            </div>

            <div className="faq-card">
              <h3>What about data privacy and compliance?</h3>
              <ul className="faq-list">
                <li><strong>GDPR Compliant:</strong> Full compliance with European data protection laws</li>
                <li><strong>SOC 2 Certified:</strong> Enterprise-grade security controls</li>
                <li><strong>HIPAA Ready:</strong> Healthcare data protection capabilities</li>
                <li><strong>Data Residency:</strong> Choose where your data is stored and processed</li>
                <li><strong>Encryption:</strong> AES-256 encryption for data at rest and in transit</li>
              </ul>
            </div>

            <div className="faq-card">
              <h3>How do you handle API rate limits?</h3>
              <ul className="faq-list">
                <li><strong>Intelligent Queuing:</strong> Request prioritization and batching</li>
                <li><strong>Multiple Providers:</strong> Failover between different AI providers</li>
                <li><strong>Caching Strategies:</strong> Reduce redundant API calls</li>
                <li><strong>Rate Limit Management:</strong> Automatic throttling and retry logic</li>
                <li><strong>Cost Optimization:</strong> Use the most cost-effective model for each task</li>
              </ul>
            </div>

            <div className="faq-card">
              <h3>Can I integrate with existing systems?</h3>
              <p>
                Absolutely! Our platform provides extensive integration capabilities:
              </p>
              <ul className="faq-list">
                <li><strong>REST APIs:</strong> Standard HTTP/JSON integrations</li>
                <li><strong>GraphQL:</strong> Flexible query language support</li>
                <li><strong>Webhooks:</strong> Real-time event notifications</li>
                <li><strong>Database Connectors:</strong> Direct database integration</li>
                <li><strong>Legacy Systems:</strong> SOAP, FTP, and custom protocol support</li>
                <li><strong>Enterprise Tools:</strong> Salesforce, ServiceNow, SAP, and more</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Cost & Pricing Section */}
        <section className="faq-section">
          <h2 className="faq-section-title">
            <CheckCircle className="faq-icon" />
            Cost & ROI
          </h2>
          <div className="faq-grid">
            <div className="faq-card">
              <h3>How is pricing structured?</h3>
              <ul className="faq-list">
                <li><strong>Usage-Based:</strong> Pay only for actual AI model usage</li>
                <li><strong>Transparent:</strong> No hidden fees or surprise charges</li>
                <li><strong>Scalable:</strong> Costs grow predictably with your business</li>
                <li><strong>Flexible:</strong> Different pricing tiers for different needs</li>
              </ul>
            </div>

            <div className="faq-card">
              <h3>What ROI can I expect?</h3>
              <ul className="faq-list">
                <li><strong>Cost Reduction:</strong> 60-80% reduction in support costs</li>
                <li><strong>Efficiency Gains:</strong> 3-5x faster response times</li>
                <li><strong>24/7 Availability:</strong> No additional staffing costs</li>
                <li><strong>Scalability:</strong> Handle 10x more requests without linear cost increase</li>
                <li><strong>Quality Improvement:</strong> Consistent, accurate responses</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Support Section */}
        <section className="faq-section">
          <h2 className="faq-section-title">
            <HelpCircle className="faq-icon" />
            Support & Next Steps
          </h2>
          <div className="faq-card full-width">
            <h3>Still have questions?</h3>
            <p>
              Our team of AI and workflow experts is here to help you understand how our platform 
              can transform your business operations.
            </p>
            <div className="faq-contact-options">
              <div className="faq-contact-item">
                <strong>Technical Consultation:</strong> Schedule a deep-dive session with our architects
              </div>
              <div className="faq-contact-item">
                <strong>Custom Demo:</strong> See the platform in action with your use case
              </div>
              <div className="faq-contact-item">
                <strong>Proof of Concept:</strong> Build a working prototype for your business
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default FAQ;