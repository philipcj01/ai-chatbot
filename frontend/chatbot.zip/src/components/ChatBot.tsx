import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, Paperclip, X, FileText, File } from 'lucide-react';
import Message from '../components/Message';
import TypingIndicator from '../components/TypingIndicator';
import type { ChatMessage, FileAttachment } from '../types/chat';
import { sendMessageToAPI } from '../services/chatService';
import './ChatBot.css';

const ChatBot: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      text: 'Hello! I\'m your AI assistant. How can I help you today? You can also attach PDF or text files for me to analyze.',
      sender: 'bot',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [hasInteracted, setHasInteracted] = useState(false);
  const [attachments, setAttachments] = useState<FileAttachment[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    // Use scrollTop instead of scrollIntoView to keep scrolling within the container
    if (messagesContainerRef.current) {
      messagesContainerRef.current.scrollTop = messagesContainerRef.current.scrollHeight;
    }
  };

  useEffect(() => {
    // Only auto-scroll after user has started interacting with the chat
    if (hasInteracted) {
      scrollToBottom();
    }
  }, [messages, isTyping, hasInteracted]);

  const handleFileAttachment = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    const validFiles: FileAttachment[] = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      
      // Check file type (PDF or text files)
      const isValidType = file.type === 'application/pdf' || 
                         file.type === 'text/plain' || 
                         file.type === 'text/markdown' ||
                         file.type === 'text/csv' ||
                         file.name.endsWith('.txt') ||
                         file.name.endsWith('.md') ||
                         file.name.endsWith('.csv');
      
      if (!isValidType) {
        alert(`File "${file.name}" is not supported. Please attach PDF or text files only.`);
        continue;
      }

      // Check file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        alert(`File "${file.name}" is too large. Maximum size is 10MB.`);
        continue;
      }

      const attachment: FileAttachment = {
        id: `${Date.now()}-${i}`,
        name: file.name,
        type: file.type,
        size: file.size,
        file: file
      };

      // For text files, read content
      if (file.type.startsWith('text/') || file.name.endsWith('.txt') || file.name.endsWith('.md') || file.name.endsWith('.csv')) {
        try {
          const content = await file.text();
          attachment.content = content;
        } catch (error) {
          console.error('Error reading file content:', error);
        }
      }

      validFiles.push(attachment);
    }

    setAttachments(prev => [...prev, ...validFiles]);
    
    // Clear the file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeAttachment = (attachmentId: string) => {
    setAttachments(prev => prev.filter(att => att.id !== attachmentId));
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() && attachments.length === 0) return;

    // Mark that user has interacted with the chat
    if (!hasInteracted) {
      setHasInteracted(true);
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: inputValue || (attachments.length > 0 ? 'Attached files for analysis' : ''),
      sender: 'user',
      timestamp: new Date(),
      attachments: attachments.length > 0 ? [...attachments] : undefined
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    const currentAttachments = [...attachments];
    setAttachments([]);
    setIsTyping(true);

    try {
      const response = await sendMessageToAPI(inputValue, currentAttachments);
      
      const botMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: response,
        sender: 'bot',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: 'Sorry, I encountered an error processing your request. Please try again.',
        sender: 'bot',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="chatbot-container">
      {/* Header */}
      <div className="chatbot-header">
        <div className="chatbot-header-content">
          <Bot className="w-6 h-6" />
          <div>
            <h2 className="chatbot-header-title">AI Assistant</h2>
            <p className="chatbot-header-status">Online</p>
          </div>
        </div>
      </div>

      {/* Messages Container */}
      <div className="chatbot-messages-container" ref={messagesContainerRef}>
        {messages.map((message) => (
          <Message key={message.id} message={message} />
        ))}
        {isTyping && <TypingIndicator />}
        <div ref={messagesEndRef} />
      </div>

      {/* File Attachments Preview */}
      {attachments.length > 0 && (
        <div className="chatbot-attachments-preview">
          {attachments.map((attachment) => (
            <div key={attachment.id} className="attachment-item">
              <div className="attachment-info">
                {attachment.type === 'application/pdf' ? (
                  <File className="w-4 h-4 text-red-500" />
                ) : (
                  <FileText className="w-4 h-4 text-blue-500" />
                )}
                <span className="attachment-name">{attachment.name}</span>
                <span className="attachment-size">({formatFileSize(attachment.size)})</span>
              </div>
              <button
                onClick={() => removeAttachment(attachment.id)}
                className="attachment-remove"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Input Area */}
      <div className="chatbot-input-area">
        <div className="chatbot-input-wrapper">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileAttachment}
            accept=".pdf,.txt,.md,.csv,text/plain,text/markdown,text/csv,application/pdf"
            multiple
            style={{ display: 'none' }}
          />
          <textarea
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder="Type your message or attach files..."
            className="chatbot-input-field"
            rows={1}
            disabled={isTyping}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="chatbot-attachment-button"
            title="Attach PDF or text files"
          >
            <Paperclip className="w-5 h-5" />
          </button>
          <button
            onClick={handleSendMessage}
            disabled={(!inputValue.trim() && attachments.length === 0) || isTyping}
            className="chatbot-send-button"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatBot;