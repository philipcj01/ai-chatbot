import React from 'react';
import { Bot, Workflow, Zap, Database, MessageSquare, Cog, ArrowRight, CheckCircle, AlertTriangle } from 'lucide-react';
import './Documentation.css';

const Documentation: React.FC = () => {
  return (
    <div className="documentation-container">
      <div className="documentation-content">
        {/* Hero Section */}
        <section className="doc-hero">
          <div className="doc-hero-content">
            <Bot className="doc-hero-icon" />
            <h1 className="doc-hero-title">AI Agentic Orchestration with Camunda</h1>
            <p className="doc-hero-subtitle">
              How our AI Chatbot leverages Camunda's workflow engine for intelligent service orchestration
            </p>
          </div>
        </section>

        {/* Architecture Overview */}
        <section className="doc-section">
          <h2 className="doc-section-title">
            <Workflow className="doc-icon" />
            Architecture Overview
          </h2>
          <div className="doc-content">
            <p>
              Our AI Chatbot utilizes Camunda's Business Process Model and Notation (BPMN) engine to orchestrate 
              intelligent workflows that combine artificial intelligence with business process automation. This creates 
              a powerful agentic system where AI agents can make decisions and trigger complex business processes.
            </p>
            
            <div className="architecture-diagram">
              <div className="arch-layer">
                <div className="arch-component user-interface">
                  <MessageSquare className="arch-icon" />
                  <span>Chat Interface</span>
                </div>
              </div>
              <ArrowRight className="arch-arrow" />
              <div className="arch-layer">
                <div className="arch-component ai-agent">
                  <Bot className="arch-icon" />
                  <span>AI Agent</span>
                </div>
              </div>
              <ArrowRight className="arch-arrow" />
              <div className="arch-layer">
                <div className="arch-component camunda-engine">
                  <Workflow className="arch-icon" />
                  <span>Camunda Engine</span>
                </div>
              </div>
              <ArrowRight className="arch-arrow" />
              <div className="arch-layer">
                <div className="arch-component services">
                  <Cog className="arch-icon" />
                  <span>Service Layer</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Key Components */}
        <section className="doc-section">
          <h2 className="doc-section-title">
            <Cog className="doc-icon" />
            Key Components
          </h2>
          <div className="doc-grid">
            <div className="doc-card">
              <div className="doc-card-header">
                <Bot className="doc-card-icon ai" />
                <h3>AI Decision Engine</h3>
              </div>
              <p>
                Natural Language Processing and Machine Learning models that interpret user intents 
                and determine the appropriate workflow to trigger in Camunda.
              </p>
              <ul className="doc-list">
                <li>Intent Recognition</li>
                <li>Context Understanding</li>
                <li>Decision Making</li>
                <li>Response Generation</li>
              </ul>
            </div>

            <div className="doc-card">
              <div className="doc-card-header">
                <Workflow className="doc-card-icon workflow" />
                <h3>Camunda BPMN Engine</h3>
              </div>
              <p>
                The core orchestration layer that manages business processes, handles service calls, 
                and maintains state throughout complex multi-step operations.
              </p>
              <ul className="doc-list">
                <li>Process Orchestration</li>
                <li>Service Task Management</li>
                <li>Error Handling</li>
                <li>Process Monitoring</li>
              </ul>
            </div>

            <div className="doc-card">
              <div className="doc-card-header">
                <Database className="doc-card-icon service" />
                <h3>Service Integration Layer</h3>
              </div>
              <p>
                External services and APIs that the AI agent can invoke through Camunda workflows 
                to perform real business operations and data retrieval.
              </p>
              <ul className="doc-list">
                <li>REST API Integration</li>
                <li>Database Operations</li>
                <li>Third-party Services</li>
                <li>Legacy System Connectivity</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Workflow Examples */}
        <section className="doc-section">
          <h2 className="doc-section-title">
            <Zap className="doc-icon" />
            Example Workflows
          </h2>
          <div className="doc-content">
            <div className="workflow-example">
              <h3>Customer Support Ticket Creation</h3>
              <div className="workflow-steps">
                <div className="workflow-step">
                  <div className="step-number">1</div>
                  <div className="step-content">
                    <h4>Intent Detection</h4>
                    <p>AI analyzes user message: "I need help with my billing"</p>
                  </div>
                </div>
                <div className="workflow-step">
                  <div className="step-number">2</div>
                  <div className="step-content">
                    <h4>Process Initiation</h4>
                    <p>Camunda starts "Support Ticket Creation" workflow</p>
                  </div>
                </div>
                <div className="workflow-step">
                  <div className="step-number">3</div>
                  <div className="step-content">
                    <h4>Service Orchestration</h4>
                    <p>Calls customer lookup, creates ticket, assigns to agent</p>
                  </div>
                </div>
                <div className="workflow-step">
                  <div className="step-number">4</div>
                  <div className="step-content">
                    <h4>Response Generation</h4>
                    <p>AI generates contextual response with ticket number</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="workflow-example">
              <h3>Account Information Retrieval</h3>
              <div className="workflow-steps">
                <div className="workflow-step">
                  <div className="step-number">1</div>
                  <div className="step-content">
                    <h4>Authentication Check</h4>
                    <p>Verify user identity and permissions</p>
                  </div>
                </div>
                <div className="workflow-step">
                  <div className="step-number">2</div>
                  <div className="step-content">
                    <h4>Data Aggregation</h4>
                    <p>Parallel service calls to multiple systems</p>
                  </div>
                </div>
                <div className="workflow-step">
                  <div className="step-number">3</div>
                  <div className="step-content">
                    <h4>Data Processing</h4>
                    <p>Transform and validate retrieved information</p>
                  </div>
                </div>
                <div className="workflow-step">
                  <div className="step-number">4</div>
                  <div className="step-content">
                    <h4>Intelligent Response</h4>
                    <p>Format response based on user context and preferences</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Benefits */}
        <section className="doc-section">
          <h2 className="doc-section-title">
            <CheckCircle className="doc-icon" />
            Benefits of AI Agentic Orchestration
          </h2>
          <div className="doc-grid">
            <div className="benefit-item">
              <CheckCircle className="benefit-icon" />
              <div>
                <h4>Scalable Intelligence</h4>
                <p>AI agents can handle complex, multi-step processes without human intervention</p>
              </div>
            </div>
            <div className="benefit-item">
              <CheckCircle className="benefit-icon" />
              <div>
                <h4>Process Visibility</h4>
                <p>Full audit trail and monitoring of all AI-initiated business processes</p>
              </div>
            </div>
            <div className="benefit-item">
              <CheckCircle className="benefit-icon" />
              <div>
                <h4>Error Resilience</h4>
                <p>Built-in retry mechanisms and error handling for robust operation</p>
              </div>
            </div>
            <div className="benefit-item">
              <CheckCircle className="benefit-icon" />
              <div>
                <h4>Service Integration</h4>
                <p>Seamless connection to existing enterprise systems and APIs</p>
              </div>
            </div>
            <div className="benefit-item">
              <CheckCircle className="benefit-icon" />
              <div>
                <h4>Adaptive Workflows</h4>
                <p>Dynamic process modification based on AI decision-making</p>
              </div>
            </div>
            <div className="benefit-item">
              <CheckCircle className="benefit-icon" />
              <div>
                <h4>Compliance & Governance</h4>
                <p>Maintain regulatory compliance through structured process execution</p>
              </div>
            </div>
          </div>
        </section>

        {/* Implementation Details */}
        <section className="doc-section">
          <h2 className="doc-section-title">
            <Database className="doc-icon" />
            Implementation in This Chatbot
          </h2>
          <div className="doc-content">
            
            <h3>Integration Points</h3>
            <div className="code-example">
              <h4>Service Configuration</h4>
              <pre><code>{`// chatService.ts - Camunda Integration Ready
const CAMUNDA_CONFIG = {
  baseUrl: process.env.CAMUNDA_CHATBOT_API_URL,
  endpoints: {
    startProcess: '/engine-rest/process-definition/key/{key}/start',
    completeTask: '/engine-rest/task/{id}/complete',
    getProcessInstance: '/engine-rest/process-instance/{id}'
  }
};`}</code></pre>
            </div>

            <div className="code-example">
              <h4>AI Agent Decision Flow</h4>
              <pre><code>{`// AI determines intent and triggers appropriate workflow
const processKey = await aiAgent.determineWorkflow(userMessage);
const processInstance = await camundaClient.startProcess(processKey, {
  userMessage,
  sessionId,
  timestamp: new Date()
});`}</code></pre>
            </div>

            <h3>Planned Workflows</h3>
            <ul className="doc-list">
              <li><strong>Customer Inquiry Processing:</strong> Route questions to appropriate services</li>
              <li><strong>Account Operations:</strong> Balance checks, transaction history, updates</li>
              <li><strong>Issue Resolution:</strong> Automated troubleshooting and escalation</li>
              <li><strong>Knowledge Base Search:</strong> Intelligent document retrieval and summarization</li>
              <li><strong>Appointment Scheduling:</strong> Calendar integration and resource management</li>
            </ul>
          </div>
        </section>

        {/* Future Enhancements */}
        <section className="doc-section">
          <h2 className="doc-section-title">
            <Zap className="doc-icon" />
            Future Enhancements
          </h2>
          <div className="doc-grid">
            <div className="doc-card future">
              <h4>Real-time Analytics</h4>
              <p>Live dashboard showing AI decision patterns and process performance metrics</p>
            </div>
            <div className="doc-card future">
              <h4>Multi-modal Interfaces</h4>
              <p>Voice, image, and document processing capabilities through Camunda workflows</p>
            </div>
            <div className="doc-card future">
              <h4>Federated Learning</h4>
              <p>Continuous improvement of AI models based on interaction patterns and outcomes</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Documentation;