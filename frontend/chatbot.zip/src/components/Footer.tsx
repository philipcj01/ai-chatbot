import React from 'react';
import { Bot, Github, Linkedin, Mail } from 'lucide-react';
import './Footer.css';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <>
      {/* Semi-transparent divider above footer */}
      <div className="footer-divider"></div>
      <footer className="footer-container">
        <div className="footer-content">
          <div className="footer-main-row">
            {/* Brand and Copyright */}
            <div className="footer-brand-section">
              <div className="footer-logo-icon">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="footer-brand-text">
                <p className="footer-brand-copyright">© {currentYear} Philip Christian Juhl. All rights reserved</p>
              </div>
            </div>

            {/* Social Links */}
            <div className="footer-social-section">
              <div className="footer-social-links">
                <a href="https://github.com/philipcj01" className="footer-social-link">
                  <Github className="w-4 h-4" />
                </a>
                <a href="https://www.linkedin.com/in/philip-christian-juhl/" className="footer-social-link">
                  <Linkedin className="w-4 h-4" />
                </a>
                <a href="mailto:philip.c.juhl@gmail.com" className="footer-social-link">
                  <Mail className="w-4 h-4" />
                </a>
              </div>
              <div className="footer-divider-vertical"></div>
              <span className="footer-tech-text">Contact for custom solutions that supports your business needs</span>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
};

export default Footer;