import React from 'react';
import { Bot, User, FileText, File, Download } from 'lucide-react';
import type { ChatMessage } from '../types/chat';
import './Message.css';

interface MessageProps {
  message: ChatMessage;
}

const Message: React.FC<MessageProps> = ({ message }) => {
  const isBot = message.sender === 'bot';

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleFileDownload = (attachment: any) => {
    // Create a blob URL and trigger download
    const url = URL.createObjectURL(attachment.file);
    const a = document.createElement('a');
    a.href = url;
    a.download = attachment.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className={`message-wrapper ${isBot ? 'message-bot' : 'message-user'}`}>
      <div className={`message-content ${isBot ? 'message-bot' : 'message-user'}`}>
        {/* Avatar */}
        <div className={`message-avatar ${isBot ? 'avatar-bot' : 'avatar-user'}`}>
          {isBot ? (
            <Bot className="w-4 h-4 text-white" />
          ) : (
            <User className="w-4 h-4 text-white" />
          )}
        </div>

        {/* Message Bubble */}
        <div className="message-bubble-container">
          <div className={`message-bubble ${isBot ? 'bubble-bot' : 'bubble-user'}`}>
            <p className="message-text">{message.text}</p>
            
            {/* File Attachments */}
            {message.attachments && message.attachments.length > 0 && (
              <div className="message-attachments">
                {message.attachments.map((attachment) => (
                  <div key={attachment.id} className="message-attachment">
                    <div className="attachment-info">
                      <div className="attachment-icon">
                        {attachment.type === 'application/pdf' ? (
                          <File className="w-4 h-4 text-red-500" />
                        ) : (
                          <FileText className="w-4 h-4 text-blue-500" />
                        )}
                      </div>
                      <div className="attachment-details">
                        <span className="attachment-name">{attachment.name}</span>
                        <span className="attachment-size">{formatFileSize(attachment.size)}</span>
                      </div>
                    </div>
                    {!isBot && (
                      <button
                        onClick={() => handleFileDownload(attachment)}
                        className="attachment-download"
                        title="Download file"
                      >
                        <Download className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {/* Timestamp */}
          <p className={`message-timestamp ${isBot ? 'timestamp-bot' : 'timestamp-user'}`}>
            {message.timestamp.toLocaleTimeString([], { 
              hour: '2-digit', 
              minute: '2-digit' 
            })}
          </p>
        </div>
      </div>
    </div>
  );
};

export default Message;