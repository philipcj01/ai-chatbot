import React from 'react';
import { Bot, TrendingUp, Shield, Clock, Users, ArrowRight, CheckCircle } from 'lucide-react';
import './SalesPage.css';

const SalesPage: React.FC = () => {
  return (
    <div className="sales-page">
      {/* Hero Section */}
      <section className="sales-hero">
        <div className="sales-hero-content">
          <div className="sales-hero-text">
            <h1 className="sales-hero-title">
              Transform Your Business with
              <span className="sales-hero-highlight"> AI Agent Solutions</span>
            </h1>
            <p className="sales-hero-description">
              Revolutionize customer service, automate workflows, and boost productivity with custom AI agents 
              tailored to your business needs. Available 24/7, intelligent, and scalable.
            </p>
          </div>
          <div className="sales-hero-visual">
            <Bot className="sales-hero-icon" />
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="sales-benefits">
        <div className="sales-section-content">
          <h2 className="sales-section-title">Why Choose AI Agents for Your Business?</h2>
          <div className="sales-benefits-grid">
            <div className="sales-benefit-card">
              <Clock className="sales-benefit-icon" />
              <h3>24/7 Availability</h3>
              <p>Never miss a customer inquiry. AI agents work around the clock to serve your customers.</p>
            </div>
            <div className="sales-benefit-card">
              <TrendingUp className="sales-benefit-icon" />
              <h3>Boost Productivity</h3>
              <p>Automate repetitive tasks and free up your team to focus on high-value activities.</p>
            </div>
            <div className="sales-benefit-card">
              <Users className="sales-benefit-icon" />
              <h3>Scalable Support</h3>
              <p>Handle thousands of conversations simultaneously without increasing headcount.</p>
            </div>
            <div className="sales-benefit-card">
              <Shield className="sales-benefit-icon" />
              <h3>Consistent Quality</h3>
              <p>Deliver uniform, accurate responses every time with AI-powered consistency.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Solutions Section */}
      <section className="sales-solutions">
        <div className="sales-section-content">
          <h2 className="sales-section-title">Tailored AI Solutions for Every Industry</h2>
          <div className="sales-solutions-grid">
            <div className="sales-solution-card">
              <h3>Customer Support Automation</h3>
              <ul className="sales-solution-features">
                <li><CheckCircle className="w-4 h-4" />Instant response to common queries</li>
                <li><CheckCircle className="w-4 h-4" />Intelligent ticket routing</li>
                <li><CheckCircle className="w-4 h-4" />Multi-language support</li>
                <li><CheckCircle className="w-4 h-4" />Seamless human handoff</li>
              </ul>
            </div>
            <div className="sales-solution-card">
              <h3>Sales & Lead Generation</h3>
              <ul className="sales-solution-features">
                <li><CheckCircle className="w-4 h-4" />Qualify leads automatically</li>
                <li><CheckCircle className="w-4 h-4" />Product recommendations</li>
                <li><CheckCircle className="w-4 h-4" />Appointment scheduling</li>
                <li><CheckCircle className="w-4 h-4" />Follow-up automation</li>
              </ul>
            </div>
            <div className="sales-solution-card">
              <h3>Internal Operations</h3>
              <ul className="sales-solution-features">
                <li><CheckCircle className="w-4 h-4" />Employee self-service</li>
                <li><CheckCircle className="w-4 h-4" />Process automation</li>
                <li><CheckCircle className="w-4 h-4" />Knowledge base integration</li>
                <li><CheckCircle className="w-4 h-4" />Workflow optimization</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* ROI Section */}
      <section className="sales-roi">
        <div className="sales-section-content">
          <h2 className="sales-section-title">Proven ROI for Growing Businesses</h2>
          <div className="sales-roi-stats">
            <div className="sales-stat-card">
              <div className="sales-stat-number">75%</div>
              <div className="sales-stat-label">Reduction in Support Costs</div>
            </div>
            <div className="sales-stat-card">
              <div className="sales-stat-number">3x</div>
              <div className="sales-stat-label">Faster Response Times</div>
            </div>
            <div className="sales-stat-card">
              <div className="sales-stat-number">95%</div>
              <div className="sales-stat-label">Customer Satisfaction</div>
            </div>
            <div className="sales-stat-card">
              <div className="sales-stat-number">40%</div>
              <div className="sales-stat-label">Increase in Lead Conversion</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="sales-cta">
        <div className="sales-cta-content">
          <h2>Ready to Transform Your Business?</h2>
          <p>Join the future now, and become one of the companies leveraging AI agents to drive growth and efficiency.</p>
          <div className="sales-cta-buttons">
            <button className="sales-btn-primary">
              Contact us now
              <ArrowRight className="w-5 h-5 ml-2" />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SalesPage;