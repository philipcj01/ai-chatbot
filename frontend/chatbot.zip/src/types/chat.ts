export interface FileAttachment {
  id: string;
  name: string;
  type: string;
  size: number;
  content?: string; // For text files
  file: File; // Original file object for API upload
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: "user" | "bot";
  timestamp: Date;
  attachments?: FileAttachment[];
}

export interface ChatState {
  messages: ChatMessage[];
  isTyping: boolean;
}

export interface APIResponse {
  message: string;
  success: boolean;
  error?: string;
}
