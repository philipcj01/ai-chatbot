import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import ChatBot from './components/ChatBot'
import Documentation from './components/Documentation'
import SalesPage from './components/SalesPage'
import FAQ from './components/FAQ'
import Header from './components/Header'
import Footer from './components/Footer'
import PageTransition from './components/PageTransition'
import './App.css'
import './components/Footer.css'

function App() {
  return (
    <Router>
      <div className="app-container">
        <Header />
        
        <div className="page-transition-wrapper">
          <Routes>
            <Route path="/" element={
              <PageTransition>
                <main className="app-main-content bg-gray-50">
                  <div className="app-content-wrapper">
                    <div className="w-full max-w-4xl">
                      <ChatBot />
                    </div>
                  </div>
                </main>
              </PageTransition>
            } />
            <Route path="/documentation" element={
              <PageTransition>
                <Documentation />
              </PageTransition>
            } />
            <Route path="/faq" element={
              <PageTransition>
                <FAQ />
              </PageTransition>
            } />
            <Route path="/get-started" element={
              <PageTransition>
                <SalesPage />
              </PageTransition>
            } />
          </Routes>
        </div>
        
        <Footer />
      </div>
    </Router>
  )
}

export default App
