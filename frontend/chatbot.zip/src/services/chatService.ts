import axios from "axios";
import type { FileAttachment } from "../types/chat";

// Enhanced mock responses that demonstrate Camunda workflow integration
const workflowResponses = {
  // Customer Support Workflows
  support: [
    "I've initiated a customer support workflow in Camunda. Creating your ticket... 🎫\n\nTicket #CS-2024-001 has been created and assigned to our support team. You'll receive updates via email.",
    "Processing your support request through our automated workflow... 🔄\n\nI've escalated this to a specialist and triggered our priority handling process. Expected response time: 2-4 hours.",
  ],

  // Account Information Workflows
  account: [
    "Accessing your account information through our secure Camunda workflow... 🔐\n\nI've retrieved your account details from multiple systems:\n• Account Status: Active\n• Last Login: Today, 10:30 AM\n• Pending Actions: None",
    "Running account verification workflow... ✅\n\nAuthentication successful! I can now access your account data through our orchestrated services. What specific information do you need?",
  ],

  // Process Orchestration Examples
  orchestration: [
    "This request requires multiple service calls - let me orchestrate them through Camunda... 🎼\n\nStep 1: ✅ User authentication\nStep 2: ✅ Data aggregation\nStep 3: ✅ Business rule validation\nStep 4: 🔄 Generating response...",
    "Triggering multi-step workflow process... ⚙️\n\nCamunda is coordinating calls to:\n→ Customer Database\n→ Transaction Service\n→ Notification Service\n→ Audit Logger\n\nAll services responded successfully!",
  ],

  // Default responses
  general: [
    "I understand your question. Let me process this through our AI-powered Camunda workflow... 🤖\n\nAnalyzing your request and determining the best service orchestration approach.",
    "Processing your request through our intelligent workflow engine... ⚡\n\nCamunda is handling the service coordination while I prepare a comprehensive response.",
    "Your query has been routed through our AI Agentic Orchestration system... 🎯\n\nMultiple backend services are being coordinated to provide you with the most accurate information.",
  ],
};

// Intent detection for demonstration
const detectIntent = (message: string): keyof typeof workflowResponses => {
  const lowerMessage = message.toLowerCase();

  if (
    lowerMessage.includes("help") ||
    lowerMessage.includes("support") ||
    lowerMessage.includes("problem") ||
    lowerMessage.includes("issue")
  ) {
    return "support";
  }

  if (
    lowerMessage.includes("account") ||
    lowerMessage.includes("balance") ||
    lowerMessage.includes("profile") ||
    lowerMessage.includes("login")
  ) {
    return "account";
  }

  if (
    lowerMessage.includes("workflow") ||
    lowerMessage.includes("process") ||
    lowerMessage.includes("orchestrat") ||
    lowerMessage.includes("camunda")
  ) {
    return "orchestration";
  }

  return "general";
};

export const sendMessageToAPI = async (
  message: string,
  attachments?: FileAttachment[]
): Promise<string> => {
  try {
    // For development/demo purposes, use enhanced mock responses
    if (import.meta.env.DEV || !import.meta.env.CAMUNDA_CHATBOT_API_URL) {
      // Simulate realistic API delay
      await new Promise((resolve) =>
        setTimeout(resolve, 1500 + Math.random() * 2000)
      );

      // Handle file attachments in mock response
      if (attachments && attachments.length > 0) {
        const fileDescriptions = attachments
          .map((att) => {
            const fileType =
              att.type === "application/pdf" ? "PDF document" : "text file";
            const content = att.content
              ? ` (${att.content.length} characters)`
              : "";
            return `📎 ${att.name} - ${fileType}${content}`;
          })
          .join("\n");

        const analysisResponse = `I've received and analyzed your attached files through our Camunda workflow: 🔍\n\n${fileDescriptions}\n\nFile processing workflow completed:\n✅ File validation\n✅ Content extraction\n✅ AI analysis\n✅ Security scan\n\nSummary: The files have been successfully processed and integrated into our knowledge base for this conversation.`;

        if (message.trim()) {
          return `${analysisResponse}\n\nRegarding your message: "${message}"\n\n${getContextualResponse(
            message
          )}`;
        }

        return analysisResponse;
      }

      // Detect intent and select appropriate response category for text-only messages
      const intent = detectIntent(message);
      const responses = workflowResponses[intent];
      const selectedResponse =
        responses[Math.floor(Math.random() * responses.length)];

      // Add contextual information about the user's message
      const contextualEnding =
        intent === "general"
          ? `\n\nRegarding your message: "${message}" - I've analyzed the context and coordinated the appropriate backend services.`
          : "";

      return selectedResponse + contextualEnding;
    }

    // Actual Camunda API integration with file upload support
    /*
    const CAMUNDA_CONFIG = {
      baseURL: import.meta.env.CAMUNDA_CHATBOT_API_URL || 'http://localhost:8080',
      timeout: 30000, // Increased timeout for file uploads
      headers: {
        'Authorization': `Bearer ${import.meta.env.CAMUNDA_API_TOKEN}`
      }
    };
    
    const apiClient = axios.create(CAMUNDA_CONFIG);
    
    // Prepare form data for file uploads
    const formData = new FormData();
    formData.append('message', message);
    formData.append('sessionId', generateSessionId());
    formData.append('timestamp', new Date().toISOString());
    
    // Add file attachments to form data
    if (attachments && attachments.length > 0) {
      attachments.forEach((attachment, index) => {
        formData.append(`file_${index}`, attachment.file);
        formData.append(`file_${index}_metadata`, JSON.stringify({
          id: attachment.id,
          name: attachment.name,
          type: attachment.type,
          size: attachment.size,
          content: attachment.content // Include text content if available
        }));
      });
      formData.append('fileCount', attachments.length.toString());
    }

    // Start a Camunda process with file upload support
    const intent = await detectWorkflowIntent(message, attachments);
    formData.append('intent', intent);
    
    const processResponse = await apiClient.post('/engine-rest/process-definition/key/chatbot-file-orchestration/start', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });

    // Poll for process completion or get intermediate results
    const processInstanceId = processResponse.data.id;
    const result = await pollProcessCompletion(apiClient, processInstanceId);
    
    return result.response || 'Files processed and workflow completed successfully';
    */

    // Fallback for when Camunda is not configured
    return `AI Agent Response: ${message}`;
  } catch (error) {
    console.error("Chat API Error:", error);

    if (axios.isAxiosError(error)) {
      if (error.response) {
        throw new Error(
          `Camunda API error: ${error.response.status} - ${
            error.response.data?.message || "Unknown error"
          }`
        );
      } else if (error.request) {
        throw new Error(
          "Network error - unable to reach Camunda engine. Please check your connection."
        );
      }
    }

    throw new Error(
      "Failed to process request through workflow engine. Please try again."
    );
  }
};

// Helper function for contextual responses
const getContextualResponse = (message: string): string => {
  const intent = detectIntent(message);
  const responses = workflowResponses[intent];
  return responses[Math.floor(Math.random() * responses.length)];
};

// Enhanced intent detection that considers file attachments
const detectWorkflowIntent = async (
  message: string,
  attachments?: FileAttachment[]
): Promise<string> => {
  // If files are attached, prioritize document analysis workflows
  if (attachments && attachments.length > 0) {
    const hasTextFiles = attachments.some(
      (att) =>
        att.type.startsWith("text/") ||
        att.name.endsWith(".txt") ||
        att.name.endsWith(".md")
    );
    const hasPDFs = attachments.some((att) => att.type === "application/pdf");

    if (hasPDFs && hasTextFiles) {
      return "document-analysis-mixed";
    } else if (hasPDFs) {
      return "pdf-analysis";
    } else if (hasTextFiles) {
      return "text-analysis";
    }
  }

  // Fall back to regular intent detection
  return detectIntent(message);
};

// Utility function for generating session IDs
const generateSessionId = (): string => {
  return `chat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

// Utility functions for future Camunda integration
export const getChatHistory = async (): Promise<any[]> => {
  // Future: Retrieve chat history from Camunda process variables
  return [];
};

export const clearChatHistory = async (): Promise<void> => {
  // Future: Clear chat session and terminate active processes
  console.log(
    "Chat history cleared - would terminate active Camunda processes"
  );
};

// Future: Advanced workflow management
export const getActiveProcesses = async (): Promise<any[]> => {
  // Retrieve active Camunda process instances for this chat session
  return [];
};

export const cancelWorkflow = async (
  processInstanceId: string
): Promise<void> => {
  // Cancel a running Camunda workflow
  console.log(`Would cancel Camunda process: ${processInstanceId}`);
};
