import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
import { BaseApiHandler } from '@shared/handlers/base-api-handler';
import { CamundaService, CamundaCorrelationRequest } from '@shared/services/camunda-service';
import { validateSchema } from '@shared/utils/validation';
import { createSuccessResponse, createErrorResponse } from '@shared/utils/response';

/**
 * Schema for message correlation request
 */
const correlationSchema = {
  type: 'object',
  properties: {
    messageName: { type: 'string', minLength: 1 },
    correlationKey: { type: 'string' },
    timeToLive: { type: 'number', minimum: 1000 },
    variables: { type: 'object' },
    processInstanceId: { type: 'string' },
    localCorrelationKeys: { type: 'object' },
  },
  required: ['messageName'],
  additionalProperties: false,
};

/**
 * Camunda Lambda Handler
 * Provides REST API endpoints for Camunda process operations
 */
class CamundaHandler extends BaseApiHandler {
  private camundaService: CamundaService;

  constructor() {
    super({ cors: true });
    this.camundaService = new CamundaService();
    this.defineRoutes();
  }

  protected defineRoutes(): void {
    // POST endpoints - only correlate endpoints
    this.registerRoute({
      method: 'POST',
      path: '/correlate',
      handler: this.correlateMessage.bind(this),
      validation: {
        body: correlationSchema,
      },
    });
  }

  /**
   * Correlate a message with a Camunda process
   */
  private async correlateMessage(
    event: APIGatewayProxyEvent,
    context: Context
  ): Promise<APIGatewayProxyResult> {
    if (!event.body) {
      return createErrorResponse('ValidationError', 'Request body is required', 400);
    }

    const requestData = JSON.parse(event.body);

    // Additional validation using the schema
    validateSchema(requestData, correlationSchema);

    const correlationRequest: CamundaCorrelationRequest = {
      messageName: requestData.messageName,
      correlationKey: requestData.correlationKey,
      timeToLive: requestData.timeToLive,
      variables: requestData.variables,
      processInstanceId: requestData.processInstanceId,
      localCorrelationKeys: requestData.localCorrelationKeys,
    };

    this.logger.info('Correlating message', {
      messageName: correlationRequest.messageName,
      correlationKey: correlationRequest.correlationKey,
      requestId: context.awsRequestId,
    });

    const result = await this.camundaService.correlateMessage(correlationRequest);

    return createSuccessResponse({
      message: 'Message correlated successfully',
      data: result,
    });
  }
}

// Create handler instance
const camundaHandler = new CamundaHandler();

// Export the handler function
export const handler = (event: APIGatewayProxyEvent, context: Context) =>
  camundaHandler.handle(event, context);
