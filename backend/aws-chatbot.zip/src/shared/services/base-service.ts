import { DynamoDBService } from '@shared/utils/dynamodb';
import { createLogger, Logger } from '@shared/utils/logger';
import { NotFoundError } from '@shared/utils/errors';

export interface BaseEntity {
  id: string;
  createdAt: string;
  updatedAt: string;
}

export interface ServiceConfig {
  tableName: string;
  region?: string;
  indexName?: string;
}

export abstract class BaseService<T extends BaseEntity> {
  protected dynamoDB: DynamoDBService;
  protected logger: Logger;
  protected config: ServiceConfig;

  constructor(config: ServiceConfig) {
    this.config = config;
    this.dynamoDB = new DynamoDBService(config.region);
    this.logger = createLogger();
  }

  /**
   * Create a new entity
   */
  async create(data: Omit<T, 'id' | 'createdAt' | 'updatedAt'>): Promise<T> {
    const now = new Date().toISOString();
    const id = this.generateId();

    const entity: T = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    } as T;

    // Validate entity before creation
    await this.validateEntity(entity);

    // Check for conflicts if needed
    await this.checkCreateConflicts(entity);

    try {
      await this.dynamoDB.putItem(this.config.tableName, entity);
      this.logger.info('Entity created successfully', { entityId: id, type: this.getEntityType() });
      return entity;
    } catch (error) {
      this.logger.error('Failed to create entity', {
        error: error instanceof Error ? error.message : 'Unknown error',
        entityId: id,
        type: this.getEntityType(),
      });
      throw error;
    }
  }

  /**
   * Get entity by ID
   */
  async getById(id: string): Promise<T | null> {
    try {
      const entity = await this.dynamoDB.getItem<T>(this.config.tableName, { id });

      if (entity) {
        this.logger.info('Entity retrieved successfully', {
          entityId: id,
          type: this.getEntityType(),
        });
      }

      return entity;
    } catch (error) {
      this.logger.error('Failed to retrieve entity', {
        error: error instanceof Error ? error.message : 'Unknown error',
        entityId: id,
        type: this.getEntityType(),
      });
      throw error;
    }
  }

  /**
   * Get entity by ID or throw NotFoundError
   */
  async getByIdOrThrow(id: string): Promise<T> {
    const entity = await this.getById(id);
    if (!entity) {
      throw new NotFoundError(`${this.getEntityType()} with ID ${id} not found`);
    }
    return entity;
  }

  /**
   * Update an existing entity
   */
  async update(id: string, updates: Partial<Omit<T, 'id' | 'createdAt'>>): Promise<T> {
    // First, verify the entity exists
    const existingEntity = await this.getByIdOrThrow(id);

    // Prepare update data
    const updateData = {
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    // Validate updates
    await this.validateUpdates(existingEntity, updateData);

    // Check for conflicts
    await this.checkUpdateConflicts(existingEntity, updateData);

    // Build update expression
    const updateExpression: string[] = [];
    const expressionAttributeValues: Record<string, any> = {};
    const expressionAttributeNames: Record<string, string> = {};

    Object.entries(updateData).forEach(([key, value]) => {
      if (value !== undefined) {
        // Handle reserved keywords by using expression attribute names
        const attributeName = this.isReservedKeyword(key) ? `#${key}` : key;
        const attributeValue = `:${key}`;

        if (this.isReservedKeyword(key)) {
          expressionAttributeNames[attributeName] = key;
        }

        updateExpression.push(`${attributeName} = ${attributeValue}`);
        expressionAttributeValues[attributeValue] = value;
      }
    });

    try {
      const updatedEntity = await this.dynamoDB.updateItem(
        this.config.tableName,
        { id },
        `SET ${updateExpression.join(', ')}`,
        expressionAttributeValues,
        Object.keys(expressionAttributeNames).length > 0 ? expressionAttributeNames : undefined
      );

      this.logger.info('Entity updated successfully', { entityId: id, type: this.getEntityType() });
      return updatedEntity as T;
    } catch (error) {
      this.logger.error('Failed to update entity', {
        error: error instanceof Error ? error.message : 'Unknown error',
        entityId: id,
        type: this.getEntityType(),
      });
      throw error;
    }
  }

  /**
   * Delete an entity
   */
  async delete(id: string): Promise<void> {
    // Verify the entity exists before deletion
    await this.getByIdOrThrow(id);

    // Check if deletion is allowed
    await this.checkDeleteConstraints(id);

    try {
      await this.dynamoDB.deleteItem(this.config.tableName, { id });
      this.logger.info('Entity deleted successfully', { entityId: id, type: this.getEntityType() });
    } catch (error) {
      this.logger.error('Failed to delete entity', {
        error: error instanceof Error ? error.message : 'Unknown error',
        entityId: id,
        type: this.getEntityType(),
      });
      throw error;
    }
  }

  /**
   * List entities with optional filtering and pagination
   */
  async list(
    options: {
      limit?: number;
      lastEvaluatedKey?: Record<string, any>;
      filterExpression?: string;
      expressionAttributeValues?: Record<string, any>;
    } = {}
  ): Promise<{
    items: T[];
    lastEvaluatedKey?: Record<string, any>;
    count: number;
  }> {
    try {
      const items = await this.dynamoDB.scanItems<T>(this.config.tableName, options.limit);

      this.logger.info('Entities listed successfully', {
        count: items.length,
        type: this.getEntityType(),
        limit: options.limit,
      });

      return {
        items,
        count: items.length,
      };
    } catch (error) {
      this.logger.error('Failed to list entities', {
        error: error instanceof Error ? error.message : 'Unknown error',
        type: this.getEntityType(),
      });
      throw error;
    }
  }

  /**
   * Query entities by a specific attribute
   */
  async queryByAttribute(
    attributeName: string,
    attributeValue: any,
    options: {
      limit?: number;
      sortAscending?: boolean;
    } = {}
  ): Promise<T[]> {
    try {
      const items = await this.dynamoDB.queryItems<T>(
        this.config.tableName,
        `${attributeName} = :value`,
        { ':value': attributeValue },
        undefined,
        options.limit
      );

      this.logger.info('Query completed successfully', {
        attribute: attributeName,
        resultCount: items.length,
        type: this.getEntityType(),
      });

      return items;
    } catch (error) {
      this.logger.error('Failed to query entities', {
        error: error instanceof Error ? error.message : 'Unknown error',
        attribute: attributeName,
        type: this.getEntityType(),
      });
      throw error;
    }
  }

  /**
   * Generate a unique ID for new entities
   */
  protected generateId(): string {
    const prefix = this.getEntityType().toLowerCase();
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 9);
    return `${prefix}-${timestamp}-${random}`;
  }

  /**
   * Check if a field name is a DynamoDB reserved keyword
   */
  protected isReservedKeyword(fieldName: string): boolean {
    const reservedKeywords = [
      'name',
      'status',
      'type',
      'date',
      'time',
      'timestamp',
      'value',
      'data',
      'key',
      'order',
      'group',
      'index',
      'count',
      'size',
      'length',
    ];
    return reservedKeywords.includes(fieldName.toLowerCase());
  }

  // Abstract methods to be implemented by child classes
  protected abstract getEntityType(): string;
  protected abstract validateEntity(entity: T): Promise<void>;
  protected abstract validateUpdates(existingEntity: T, updates: any): Promise<void>;
  protected abstract checkCreateConflicts(entity: T): Promise<void>;
  protected abstract checkUpdateConflicts(existingEntity: T, updates: any): Promise<void>;
  protected abstract checkDeleteConstraints(id: string): Promise<void>;
}
