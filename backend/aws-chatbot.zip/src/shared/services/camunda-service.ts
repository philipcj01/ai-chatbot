import axios, { AxiosInstance, AxiosResponse, AxiosError } from 'axios';
import { createLogger, Logger } from '@shared/utils/logger';
import { ValidationError, ServiceError } from '@shared/utils/errors';

export interface CamundaCorrelationRequest {
  messageName: string;
  correlationKey?: string;
  timeToLive?: number;
  variables?: Record<string, any>;
  processInstanceId?: string;
  localCorrelationKeys?: Record<string, string>;
}

export interface CamundaCorrelationResponse {
  key: number;
  processDefinitionKey: number;
  bpmnProcessId: string;
  version: number;
  processInstanceKey: number;
}

export interface CamundaProcessInstance {
  processInstanceKey: number;
  processDefinitionKey: number;
  bpmnProcessId: string;
  version: number;
  state: 'ACTIVE' | 'COMPLETED' | 'TERMINATED';
  parentProcessInstanceKey?: number;
  parentElementInstanceKey?: number;
}

export interface CamundaServiceConfig {
  endpoint: string;
  clusterId: string;
  clientId?: string | undefined;
  clientSecret?: string | undefined;
  region?: string;
  timeout?: number;
}

export interface TokenResponse {
  access_token: string;
  expires_in: number;
  token_type: string;
}

/**
 * Camunda 8 adapter service for interacting with Camunda Cloud/Zeebe
 * Handles process instance correlation and basic process operations
 */
export class CamundaService {
  private readonly client: AxiosInstance;
  private readonly logger: Logger;
  private readonly config: CamundaServiceConfig;
  private authToken?: string;
  private tokenExpiry?: Date;

  constructor(config?: Partial<CamundaServiceConfig>) {
    this.logger = createLogger();

    // Load configuration from environment variables with fallbacks
    this.config = {
      endpoint: config?.endpoint ?? process.env.CAMUNDA_ENDPOINT ?? '',
      clusterId: config?.clusterId ?? process.env.CAMUNDA_CLUSTER_ID ?? '',
      clientId: config?.clientId ?? process.env.CAMUNDA_CLIENT_ID,
      clientSecret: config?.clientSecret ?? process.env.CAMUNDA_CLIENT_SECRET,
      region: config?.region ?? process.env.CAMUNDA_REGION ?? 'fra-1',
      timeout: config?.timeout ?? 30000,
    };

    this.validateConfig();

    // Create axios instance with base configuration
    this.client = axios.create({
      baseURL: this.getBaseUrl(),
      timeout: this.config.timeout ?? 30000,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
    });

    // Add request interceptor for authentication
    this.client.interceptors.request.use(
      async (config: import('axios').InternalAxiosRequestConfig) => {
        const token = await this.getAuthToken();
        if (token && config.headers) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error: AxiosError) => {
        this.logger.error('Request interceptor error', { error: error.message });
        return Promise.reject(error);
      }
    );

    // Add response interceptor for error handling
    this.client.interceptors.response.use(
      (response: AxiosResponse) => response,
      (error: AxiosError) => {
        this.logger.error('Camunda API error', {
          status: error.response?.status,
          statusText: error.response?.statusText,
          data: error.response?.data,
          url: error.config?.url,
          method: error.config?.method,
        });
        return Promise.reject(this.handleApiError(error));
      }
    );
  }

  /**
   * Correlate a message to start or continue a process instance
   */
  async correlateMessage(request: CamundaCorrelationRequest): Promise<CamundaCorrelationResponse> {
    this.validateCorrelationRequest(request);

    try {
      this.logger.info('Correlating message with Camunda', {
        messageName: request.messageName,
        correlationKey: request.correlationKey,
        hasVariables: !!request.variables && Object.keys(request.variables).length > 0,
      });

      const payload = {
        messageName: request.messageName,
        correlationKey: request.correlationKey,
        timeToLive: request.timeToLive ?? 60000, // Default 60 seconds
        variables: this.formatVariables(request.variables),
        ...(request.processInstanceId && { processInstanceId: request.processInstanceId }),
        ...(request.localCorrelationKeys && { localCorrelationKeys: request.localCorrelationKeys }),
      };

      const response: AxiosResponse<CamundaCorrelationResponse> = await this.client.post(
        '/message/correlation',
        payload
      );

      this.logger.info('Message correlated successfully', {
        messageName: request.messageName,
        processInstanceKey: response.data.processInstanceKey,
        bpmnProcessId: response.data.bpmnProcessId,
      });

      return response.data;
    } catch (error) {
      this.logger.error('Failed to correlate message', {
        messageName: request.messageName,
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      throw error;
    }
  }

  /**
   * Start a new process instance
   */
  async startProcess(
    bpmnProcessId: string,
    variables?: Record<string, any>
  ): Promise<CamundaProcessInstance> {
    try {
      this.logger.info('Starting new process instance', {
        bpmnProcessId,
        hasVariables: !!variables && Object.keys(variables).length > 0,
      });

      const payload = {
        bpmnProcessId,
        variables: this.formatVariables(variables),
      };

      const response: AxiosResponse<CamundaProcessInstance> = await this.client.post(
        '/process-instances',
        payload
      );

      this.logger.info('Process instance started successfully', {
        bpmnProcessId,
        processInstanceKey: response.data.processInstanceKey,
      });

      return response.data;
    } catch (error) {
      this.logger.error('Failed to start process instance', {
        bpmnProcessId,
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      throw error;
    }
  }

  /**
   * Get process instance details
   */
  async getProcessInstance(processInstanceKey: number): Promise<CamundaProcessInstance> {
    try {
      const response: AxiosResponse<CamundaProcessInstance> = await this.client.get(
        `/process-instances/${processInstanceKey}`
      );

      return response.data;
    } catch (error) {
      this.logger.error('Failed to get process instance', {
        processInstanceKey,
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      throw error;
    }
  }

  /**
   * Cancel a process instance
   */
  async cancelProcessInstance(processInstanceKey: number): Promise<void> {
    try {
      this.logger.info('Cancelling process instance', { processInstanceKey });

      await this.client.delete(`/process-instances/${processInstanceKey}`);

      this.logger.info('Process instance cancelled successfully', { processInstanceKey });
    } catch (error) {
      this.logger.error('Failed to cancel process instance', {
        processInstanceKey,
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      throw error;
    }
  }

  /**
   * Publish a message (fire-and-forget)
   */
  async publishMessage(
    messageName: string,
    correlationKey?: string,
    variables?: Record<string, any>,
    timeToLive?: number
  ): Promise<void> {
    try {
      this.logger.info('Publishing message to Camunda', {
        messageName,
        correlationKey,
        hasVariables: !!variables && Object.keys(variables).length > 0,
      });

      const payload = {
        name: messageName,
        correlationKey,
        variables: this.formatVariables(variables),
        timeToLive: timeToLive ?? 60000,
      };

      await this.client.post('/messages', payload);

      this.logger.info('Message published successfully', { messageName, correlationKey });
    } catch (error) {
      this.logger.error('Failed to publish message', {
        messageName,
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      throw error;
    }
  }

  /**
   * Health check for Camunda service
   */
  async healthCheck(): Promise<{ status: 'healthy' | 'unhealthy'; timestamp: string }> {
    try {
      // Try to make a simple request to check connectivity
      await this.client.get('/topology');

      return {
        status: 'healthy',
        timestamp: new Date().toISOString(),
      };
    } catch (error) {
      this.logger.error('Camunda health check failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
      });

      return {
        status: 'unhealthy',
        timestamp: new Date().toISOString(),
      };
    }
  }

  private validateConfig(): void {
    if (!this.config.endpoint) {
      throw new ValidationError('CAMUNDA_ENDPOINT environment variable is required');
    }
    if (!this.config.clusterId) {
      throw new ValidationError('CAMUNDA_CLUSTER_ID environment variable is required');
    }
  }

  private validateCorrelationRequest(request: CamundaCorrelationRequest): void {
    if (!request.messageName) {
      throw new ValidationError('messageName is required for message correlation');
    }
  }

  private getBaseUrl(): string {
    return `${this.config.endpoint}/v1/clusters/${this.config.clusterId}`;
  }

  private async getAuthToken(): Promise<string | null> {
    // If using Camunda Cloud, implement OAuth2 token retrieval
    // For now, return null (for self-managed Camunda without auth)
    if (!this.config.clientId || !this.config.clientSecret) {
      return null;
    }

    // Check if we have a valid token
    if (this.authToken && this.tokenExpiry && new Date() < this.tokenExpiry) {
      return this.authToken;
    }

    try {
      // Implement OAuth2 token exchange for Camunda Cloud
      const tokenUrl = `https://login.cloud.camunda.io/oauth/token`;
      const response = await axios.post<TokenResponse>(tokenUrl, {
        grant_type: 'client_credentials',
        audience: `zeebe.camunda.io`,
        client_id: this.config.clientId,
        client_secret: this.config.clientSecret,
      });

      this.authToken = response.data.access_token;
      this.tokenExpiry = new Date(Date.now() + response.data.expires_in * 1000 - 60000); // Refresh 1 minute early

      return this.authToken ?? null;
    } catch (error) {
      this.logger.error('Failed to obtain auth token', {
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      return null;
    }
  }

  private formatVariables(variables?: Record<string, any>): Record<string, any> | undefined {
    if (!variables) return undefined;

    // Camunda expects variables in a specific format
    const formatted: Record<string, any> = {};

    Object.entries(variables).forEach(([key, value]) => {
      formatted[key] = {
        value,
        type: this.getVariableType(value),
      };
    });

    return formatted;
  }

  private getVariableType(value: any): string {
    if (typeof value === 'string') return 'String';
    if (typeof value === 'number') return Number.isInteger(value) ? 'Long' : 'Double';
    if (typeof value === 'boolean') return 'Boolean';
    if (value instanceof Date) return 'Date';
    if (typeof value === 'object' && value !== null) return 'Json';
    return 'String'; // Default fallback
  }

  private handleApiError(error: AxiosError): Error {
    if (error.response) {
      const status = error.response.status;
      const message = (error.response.data as any)?.message || error.response.statusText;

      switch (status) {
        case 400:
          return new ValidationError(`Camunda API validation error: ${message}`);
        case 401:
          return new ServiceError(`Camunda authentication failed: ${message}`, 401);
        case 403:
          return new ServiceError(`Camunda authorization failed: ${message}`, 403);
        case 404:
          return new ServiceError(`Camunda resource not found: ${message}`, 404);
        case 429:
          return new ServiceError(`Camunda rate limit exceeded: ${message}`, 429);
        case 500:
          return new ServiceError(`Camunda internal server error: ${message}`, 500);
        default:
          return new ServiceError(`Camunda API error: ${message}`, status);
      }
    }

    if (error.code === 'ECONNREFUSED' || error.code === 'ETIMEDOUT') {
      return new ServiceError('Unable to connect to Camunda service', 503);
    }

    return new ServiceError(`Camunda service error: ${error.message}`, 500);
  }
}
