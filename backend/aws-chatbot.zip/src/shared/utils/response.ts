import { APIGatewayProxyResult } from 'aws-lambda';
import { ErrorResponse, SuccessResponse } from '@shared/types';

/**
 * Creates a standardized success response
 */
export const createSuccessResponse = <T>(
  data: T,
  statusCode: number = 200,
  headers: Record<string, string> = {}
): APIGatewayProxyResult => {
  const response: SuccessResponse<T> = {
    success: true,
    data,
    timestamp: new Date().toISOString(),
  };

  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers':
        'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      ...headers,
    },
    body: JSON.stringify(response),
  };
};

/**
 * Creates a standardized error response
 */
export const createErrorResponse = (
  error: string,
  message: string,
  statusCode: number = 500,
  headers: Record<string, string> = {}
): APIGatewayProxyResult => {
  const response: ErrorResponse = {
    error,
    message,
    timestamp: new Date().toISOString(),
  };

  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers':
        'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      ...headers,
    },
    body: JSON.stringify(response),
  };
};

/**
 * Handles CORS preflight requests
 */
export const createCorsResponse = (): APIGatewayProxyResult => {
  return {
    statusCode: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers':
        'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    },
    body: '',
  };
};
