/**
 * Base class for API errors
 */
export abstract class ApiError extends Error {
  abstract readonly statusCode: number;
  abstract readonly errorType: string;

  constructor(message: string) {
    super(message);
    this.name = this.constructor.name;
    Error.captureStackTrace(this, this.constructor);
  }
}

/**
 * Validation error for request validation failures
 */
export class ValidationError extends ApiError {
  readonly statusCode = 400;
  readonly errorType = 'ValidationError';

  constructor(message: string) {
    super(message);
  }
}

/**
 * Not found error for missing resources
 */
export class NotFoundError extends ApiError {
  readonly statusCode = 404;
  readonly errorType = 'NotFound';

  constructor(message: string = 'Resource not found') {
    super(message);
  }
}

/**
 * Unauthorized error for authentication failures
 */
export class UnauthorizedError extends ApiError {
  readonly statusCode = 401;
  readonly errorType = 'Unauthorized';

  constructor(message: string = 'Access denied') {
    super(message);
  }
}

/**
 * Forbidden error for authorization failures
 */
export class ForbiddenError extends ApiError {
  readonly statusCode = 403;
  readonly errorType = 'Forbidden';

  constructor(message: string = 'Insufficient permissions') {
    super(message);
  }
}

/**
 * Conflict error for resource conflicts
 */
export class ConflictError extends ApiError {
  readonly statusCode = 409;
  readonly errorType = 'Conflict';

  constructor(message: string) {
    super(message);
  }
}

/**
 * Internal server error for unexpected errors
 */
export class InternalServerError extends ApiError {
  readonly statusCode = 500;
  readonly errorType = 'InternalServerError';

  constructor(message: string = 'Internal server error') {
    super(message);
  }
}

/**
 * Generic service error with configurable status code
 */
export class ServiceError extends ApiError {
  readonly errorType = 'ServiceError';

  constructor(
    message: string,
    public readonly statusCode: number = 500
  ) {
    super(message);
  }
}
