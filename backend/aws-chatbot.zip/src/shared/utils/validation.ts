import { z, ZodSchema, ZodError, ZodIssue } from 'zod';
import { ValidationError } from '@shared/utils/errors';
import { createLogger } from '@shared/utils/logger';
import {
  APIGatewayProxyEventQueryStringParameters,
  APIGatewayProxyEventPathParameters,
} from 'aws-lambda';

/**
 * Validation result interface
 */
export interface ValidationResult<T> {
  success: boolean;
  data?: T;
  errors?: ValidationErrorDetail[];
}

/**
 * Detailed validation error information
 */
export interface ValidationErrorDetail {
  field: string;
  message: string;
  code: string;
  value?: unknown;
}

/**
 * Validation options
 */
export interface ValidationOptions {
  throwOnError?: boolean;
  logErrors?: boolean;
  context?: string;
}

/**
 * Generic Zod schema validation function
 */
export async function validateSchema<T>(
  schema: ZodSchema<T>,
  data: unknown,
  options: ValidationOptions = {}
): Promise<ValidationResult<T>> {
  const { throwOnError = false, logErrors = true, context = 'validation' } = options;

  const logger = createLogger();

  try {
    // For non-strict mode, we'll just use the original schema
    // Zod by default strips unknown properties in object schemas
    const result = await schema.parseAsync(data);

    if (logErrors) {
      logger.debug('Schema validation successful', {
        context,
        dataType: typeof data,
        schemaName: schema.constructor.name,
      });
    }

    return {
      success: true,
      data: result,
    };
  } catch (error) {
    const validationErrors = formatZodErrors(error as ZodError);

    if (logErrors) {
      logger.warn('Schema validation failed', {
        context,
        errors: validationErrors,
        data: typeof data === 'object' ? JSON.stringify(data) : data,
      });
    }

    if (throwOnError) {
      const errorMessage = `Validation failed: ${validationErrors.map(e => e.message).join(', ')}`;
      throw new ValidationError(errorMessage);
    }

    return {
      success: false,
      errors: validationErrors,
    };
  }
}

/**
 * Synchronous version of validateSchema
 */
export function validateSchemaSync<T>(
  schema: ZodSchema<T>,
  data: unknown,
  options: ValidationOptions = {}
): ValidationResult<T> {
  const { throwOnError = false, logErrors = true, context = 'validation' } = options;

  const logger = createLogger();

  try {
    const result = schema.parse(data);

    if (logErrors) {
      logger.debug('Schema validation successful', {
        context,
        dataType: typeof data,
        schemaName: schema.constructor.name,
      });
    }

    return {
      success: true,
      data: result,
    };
  } catch (error) {
    const validationErrors = formatZodErrors(error as ZodError);

    if (logErrors) {
      logger.warn('Schema validation failed', {
        context,
        errors: validationErrors,
        data: typeof data === 'object' ? JSON.stringify(data) : data,
      });
    }

    if (throwOnError) {
      const errorMessage = `Validation failed: ${validationErrors.map(e => e.message).join(', ')}`;
      throw new ValidationError(errorMessage);
    }

    return {
      success: false,
      errors: validationErrors,
    };
  }
}

/**
 * Validate API Gateway event body
 */
export async function validateEventBody<T>(
  schema: ZodSchema<T>,
  body: string | null,
  options: ValidationOptions = {}
): Promise<ValidationResult<T>> {
  if (!body) {
    const error: ValidationErrorDetail = {
      field: 'body',
      message: 'Request body is required',
      code: 'required',
    };

    if (options.throwOnError) {
      throw new ValidationError('Request body is required');
    }

    return {
      success: false,
      errors: [error],
    };
  }

  try {
    const parsedBody = JSON.parse(body);
    return await validateSchema(schema, parsedBody, {
      ...options,
      context: 'event-body',
    });
  } catch (parseError) {
    const error: ValidationErrorDetail = {
      field: 'body',
      message: 'Invalid JSON in request body',
      code: 'invalid_json',
    };

    if (options.throwOnError) {
      throw new ValidationError('Invalid JSON in request body');
    }

    return {
      success: false,
      errors: [error],
    };
  }
}

/**
 * Validate query parameters - handles API Gateway parameter types
 */
export async function validateQueryParams<T>(
  schema: ZodSchema<T>,
  queryParams: APIGatewayProxyEventQueryStringParameters | null,
  options: ValidationOptions = {}
): Promise<ValidationResult<T>> {
  const params = queryParams || {};
  return await validateSchema(schema, params, {
    ...options,
    context: 'query-params',
  });
}

/**
 * Validate path parameters - handles API Gateway parameter types
 */
export async function validatePathParams<T>(
  schema: ZodSchema<T>,
  pathParams: APIGatewayProxyEventPathParameters | null,
  options: ValidationOptions = {}
): Promise<ValidationResult<T>> {
  const params = pathParams || {};
  return await validateSchema(schema, params, {
    ...options,
    context: 'path-params',
  });
}

/**
 * Create a validation middleware for the base handler
 */
export function createValidationMiddleware<TBody = any, TQuery = any, TPath = any>(config: {
  bodySchema?: ZodSchema<TBody>;
  querySchema?: ZodSchema<TQuery>;
  pathSchema?: ZodSchema<TPath>;
  options?: ValidationOptions;
}) {
  return async (
    event: any
  ): Promise<{
    body?: TBody;
    query?: TQuery;
    path?: TPath;
  }> => {
    const results: any = {};
    const { options = {} } = config;

    // Validate body
    if (config.bodySchema) {
      const bodyResult = await validateEventBody(config.bodySchema, event.body, {
        ...options,
        throwOnError: true,
      });
      if (bodyResult.success) {
        results.body = bodyResult.data;
      }
    }

    // Validate query parameters
    if (config.querySchema) {
      const queryResult = await validateQueryParams(
        config.querySchema,
        event.queryStringParameters,
        { ...options, throwOnError: true }
      );
      if (queryResult.success) {
        results.query = queryResult.data;
      }
    }

    // Validate path parameters
    if (config.pathSchema) {
      const pathResult = await validatePathParams(config.pathSchema, event.pathParameters, {
        ...options,
        throwOnError: true,
      });
      if (pathResult.success) {
        results.path = pathResult.data;
      }
    }

    return results;
  };
}

/**
 * Format Zod errors into a more readable format
 */
function formatZodErrors(error: ZodError): ValidationErrorDetail[] {
  return error.issues.map((issue: ZodIssue) => {
    const field = issue.path.length > 0 ? issue.path.join('.') : 'root';

    return {
      field,
      message: issue.message,
      code: issue.code,
      value: 'received' in issue ? issue.received : undefined,
    };
  });
}

/**
 * Common schema patterns for reuse
 */
export const CommonSchemas = {
  // Basic types
  id: z.string().min(1, 'ID is required').max(100, 'ID too long'),
  email: z.string().email('Invalid email format'),
  url: z.string().url('Invalid URL format'),

  // Pagination
  pagination: z.object({
    page: z.coerce.number().int().min(1).default(1),
    limit: z.coerce.number().int().min(1).max(100).default(10),
    offset: z.coerce.number().int().min(0).optional(),
  }),

  // Common query parameters
  search: z.object({
    q: z.string().min(1, 'Search query is required').max(200, 'Search query too long'),
    fields: z.string().optional(),
    sort: z.string().optional(),
  }),

  // Date ranges
  dateRange: z
    .object({
      startDate: z.string().datetime().optional(),
      endDate: z.string().datetime().optional(),
    })
    .refine((data: any) => {
      if (data.startDate && data.endDate) {
        return new Date(data.startDate) <= new Date(data.endDate);
      }
      return true;
    }, 'Start date must be before end date'),

  // AWS resource names
  awsResourceName: z
    .string()
    .min(1, 'Resource name is required')
    .max(63, 'Resource name too long')
    .regex(/^[a-zA-Z0-9-_]+$/, 'Invalid resource name format'),

  // Environment variables
  environment: z.enum(['development', 'staging', 'production', 'test']),

  // HTTP methods
  httpMethod: z.enum(['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS', 'HEAD']),
};

/**
 * Schema transformation utilities
 */
export const SchemaTransforms = {
  /**
   * Transform string to lowercase
   */
  toLowerCase: z.string().transform((val: string) => val.toLowerCase()),

  /**
   * Transform string to uppercase
   */
  toUpperCase: z.string().transform((val: string) => val.toUpperCase()),

  /**
   * Trim whitespace
   */
  trim: z.string().transform((val: string) => val.trim()),

  /**
   * Parse JSON string
   */
  parseJson: z.string().transform((val: string, ctx: any) => {
    try {
      return JSON.parse(val);
    } catch {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Invalid JSON string',
      });
      return z.NEVER;
    }
  }),

  /**
   * Parse comma-separated values
   */
  parseCsv: z.string().transform((val: string) =>
    val
      .split(',')
      .map((item: string) => item.trim())
      .filter((item: string) => item.length > 0)
  ),
};
