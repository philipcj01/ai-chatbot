import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import {
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand,
  UpdateCommand,
  DeleteCommand,
  ScanCommand,
  QueryCommand,
  GetCommandInput,
  PutCommandInput,
  UpdateCommandInput,
  DeleteCommandInput,
  ScanCommandInput,
  QueryCommandInput,
} from '@aws-sdk/lib-dynamodb';
import { createLogger } from '@shared/utils/logger';

export class DynamoDBService {
  private client: DynamoDBDocumentClient;
  private logger = createLogger();

  constructor(region: string = process.env.AWS_REGION || 'us-east-1') {
    const dynamoClient = new DynamoDBClient({ region });
    this.client = DynamoDBDocumentClient.from(dynamoClient);
  }

  /**
   * Get an item from DynamoDB
   */
  async getItem<T>(tableName: string, key: Record<string, any>): Promise<T | null> {
    try {
      const params: GetCommandInput = {
        TableName: tableName,
        Key: key,
      };

      this.logger.info('Getting item from DynamoDB', { tableName, key });
      const result = await this.client.send(new GetCommand(params));

      return (result.Item as T) || null;
    } catch (error) {
      this.logger.error('Failed to get item from DynamoDB', {
        error: error instanceof Error ? error.message : 'Unknown error',
        tableName,
        key,
      });
      throw error;
    }
  }

  /**
   * Put an item into DynamoDB
   */
  async putItem<T extends Record<string, any>>(tableName: string, item: T): Promise<void> {
    try {
      const params: PutCommandInput = {
        TableName: tableName,
        Item: item,
      };

      this.logger.info('Putting item into DynamoDB', { tableName });
      await this.client.send(new PutCommand(params));
    } catch (error) {
      this.logger.error('Failed to put item into DynamoDB', {
        error: error instanceof Error ? error.message : 'Unknown error',
        tableName,
      });
      throw error;
    }
  }

  /**
   * Update an item in DynamoDB
   */
  async updateItem(
    tableName: string,
    key: Record<string, any>,
    updateExpression: string,
    expressionAttributeValues: Record<string, any>,
    expressionAttributeNames?: Record<string, string>
  ): Promise<any> {
    try {
      const params: UpdateCommandInput = {
        TableName: tableName,
        Key: key,
        UpdateExpression: updateExpression,
        ExpressionAttributeValues: expressionAttributeValues,
        ExpressionAttributeNames: expressionAttributeNames,
        ReturnValues: 'ALL_NEW',
      };

      this.logger.info('Updating item in DynamoDB', { tableName, key });
      const result = await this.client.send(new UpdateCommand(params));

      return result.Attributes;
    } catch (error) {
      this.logger.error('Failed to update item in DynamoDB', {
        error: error instanceof Error ? error.message : 'Unknown error',
        tableName,
        key,
      });
      throw error;
    }
  }

  /**
   * Delete an item from DynamoDB
   */
  async deleteItem(tableName: string, key: Record<string, any>): Promise<void> {
    try {
      const params: DeleteCommandInput = {
        TableName: tableName,
        Key: key,
      };

      this.logger.info('Deleting item from DynamoDB', { tableName, key });
      await this.client.send(new DeleteCommand(params));
    } catch (error) {
      this.logger.error('Failed to delete item from DynamoDB', {
        error: error instanceof Error ? error.message : 'Unknown error',
        tableName,
        key,
      });
      throw error;
    }
  }

  /**
   * Query items from DynamoDB
   */
  async queryItems<T>(
    tableName: string,
    keyConditionExpression: string,
    expressionAttributeValues: Record<string, any>,
    expressionAttributeNames?: Record<string, string>,
    limit?: number
  ): Promise<T[]> {
    try {
      const params: QueryCommandInput = {
        TableName: tableName,
        KeyConditionExpression: keyConditionExpression,
        ExpressionAttributeValues: expressionAttributeValues,
        ExpressionAttributeNames: expressionAttributeNames,
        Limit: limit,
      };

      this.logger.info('Querying items from DynamoDB', { tableName });
      const result = await this.client.send(new QueryCommand(params));

      return (result.Items as T[]) || [];
    } catch (error) {
      this.logger.error('Failed to query items from DynamoDB', {
        error: error instanceof Error ? error.message : 'Unknown error',
        tableName,
      });
      throw error;
    }
  }

  /**
   * Scan items from DynamoDB
   */
  async scanItems<T>(tableName: string, limit?: number): Promise<T[]> {
    try {
      const params: ScanCommandInput = {
        TableName: tableName,
        Limit: limit,
      };

      this.logger.info('Scanning items from DynamoDB', { tableName });
      const result = await this.client.send(new ScanCommand(params));

      return (result.Items as T[]) || [];
    } catch (error) {
      this.logger.error('Failed to scan items from DynamoDB', {
        error: error instanceof Error ? error.message : 'Unknown error',
        tableName,
      });
      throw error;
    }
  }
}
