export enum LogLevel {
  ERROR = 'ERROR',
  WARN = 'WARN',
  INFO = 'INFO',
  DEBUG = 'DEBUG',
}

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  requestId?: string;
  functionName?: string;
  functionVersion?: string;
  awsRegion?: string;
  metadata?: Record<string, any>;
}

class Logger {
  private requestId?: string;
  private functionName?: string;
  private functionVersion?: string;
  private awsRegion?: string;

  constructor(
    requestId?: string,
    functionName?: string,
    functionVersion?: string,
    awsRegion?: string
  ) {
    if (requestId !== undefined) this.requestId = requestId;
    if (functionName !== undefined) this.functionName = functionName;
    if (functionVersion !== undefined) this.functionVersion = functionVersion;
    if (awsRegion !== undefined) this.awsRegion = awsRegion;
  }

  private log(level: LogLevel, message: string, metadata?: Record<string, any>): void {
    const logEntry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      message,
    };

    if (this.requestId) logEntry.requestId = this.requestId;
    if (this.functionName) logEntry.functionName = this.functionName;
    if (this.functionVersion) logEntry.functionVersion = this.functionVersion;
    if (this.awsRegion) logEntry.awsRegion = this.awsRegion;
    if (metadata) logEntry.metadata = metadata;

    console.log(JSON.stringify(logEntry));
  }

  error(message: string, metadata?: Record<string, any>): void {
    this.log(LogLevel.ERROR, message, metadata);
  }

  warn(message: string, metadata?: Record<string, any>): void {
    this.log(LogLevel.WARN, message, metadata);
  }

  info(message: string, metadata?: Record<string, any>): void {
    this.log(LogLevel.INFO, message, metadata);
  }

  debug(message: string, metadata?: Record<string, any>): void {
    this.log(LogLevel.DEBUG, message, metadata);
  }
}

export { Logger };

/**
 * Creates a logger instance with Lambda context information
 */
export const createLogger = (context?: {
  awsRequestId?: string;
  functionName?: string;
  functionVersion?: string;
  invokedFunctionArn?: string;
}): Logger => {
  return new Logger(
    context?.awsRequestId,
    context?.functionName,
    context?.functionVersion,
    process.env.AWS_REGION
  );
};
