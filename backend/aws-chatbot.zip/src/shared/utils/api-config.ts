import { APIGatewayProxyEvent } from 'aws-lambda';
import { ApiConfig } from '@shared/handlers/base-api-handler';

/**
 * JWT token validation interface
 */
export interface JwtPayload {
  sub: string;
  aud: string;
  iss: string;
  exp: number;
  iat: number;
  [key: string]: any;
}

/**
 * API Key validation interface
 */
export interface ApiKeyConfig {
  headerName?: string;
  validKeys?: string[];
  validateFunction?: (key: string) => Promise<boolean>;
}

/**
 * Creates configuration for a public API (no authentication required)
 */
export function createPublicApiConfig(
  options: {
    cors?: boolean;
    basePath?: string;
  } = {}
): ApiConfig {
  const config: ApiConfig = {
    cors: options.cors ?? true,
  };

  if (options.basePath !== undefined) {
    config.basePath = options.basePath;
  }

  return config;
}

/**
 * Creates configuration for a private API with JWT authentication
 */
export function createPrivateJwtApiConfig(
  options: {
    jwtSecret?: string;
    jwtIssuer?: string;
    jwtAudience?: string;
    cors?: boolean;
    basePath?: string;
    customValidator?: (payload: JwtPayload) => Promise<boolean>;
  } = {}
): ApiConfig {
  const config: ApiConfig = {
    cors: options.cors ?? true,
    auth: {
      type: 'jwt',
      validator: async (event: APIGatewayProxyEvent): Promise<boolean> => {
        try {
          const authHeader = event.headers.Authorization || event.headers.authorization;
          if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return false;
          }

          const token = authHeader.substring(7);

          // In a real implementation, you would validate the JWT token here
          // For now, we'll do a basic validation
          if (!token || token.length < 10) {
            return false;
          }

          // If a custom validator is provided, use it
          if (options.customValidator) {
            // In a real implementation, you would decode the JWT first
            const mockPayload: JwtPayload = {
              sub: 'user-id',
              aud: options.jwtAudience || 'api',
              iss: options.jwtIssuer || 'issuer',
              exp: Math.floor(Date.now() / 1000) + 3600,
              iat: Math.floor(Date.now() / 1000),
            };
            return await options.customValidator(mockPayload);
          }

          return true;
        } catch (error) {
          return false;
        }
      },
    },
  };

  if (options.basePath !== undefined) {
    config.basePath = options.basePath;
  }

  return config;
}

/**
 * Creates configuration for a private API with API key authentication
 */
export function createPrivateApiKeyConfig(
  options: {
    apiKeyConfig: ApiKeyConfig;
    cors?: boolean;
    basePath?: string;
  } = { apiKeyConfig: {} }
): ApiConfig {
  const { apiKeyConfig } = options;
  const headerName = apiKeyConfig.headerName || 'X-API-Key';

  const config: ApiConfig = {
    cors: options.cors ?? true,
    auth: {
      type: 'api-key',
      validator: async (event: APIGatewayProxyEvent): Promise<boolean> => {
        try {
          const apiKey = event.headers[headerName] || event.headers[headerName.toLowerCase()];

          if (!apiKey) {
            return false;
          }

          // Use custom validation function if provided
          if (apiKeyConfig.validateFunction) {
            return await apiKeyConfig.validateFunction(apiKey);
          }

          // Use provided valid keys list
          if (apiKeyConfig.validKeys && apiKeyConfig.validKeys.length > 0) {
            return apiKeyConfig.validKeys.includes(apiKey);
          }

          // Default: check if API key exists and has minimum length
          return apiKey.length >= 32;
        } catch (error) {
          return false;
        }
      },
    },
  };

  if (options.basePath !== undefined) {
    config.basePath = options.basePath;
  }

  return config;
}

/**
 * Creates configuration for a private API with custom authentication
 */
export function createPrivateCustomApiConfig(options: {
  validator: (event: APIGatewayProxyEvent) => Promise<boolean>;
  cors?: boolean;
  basePath?: string;
}): ApiConfig {
  const config: ApiConfig = {
    cors: options.cors ?? true,
    auth: {
      type: 'custom',
      validator: options.validator,
    },
  };

  if (options.basePath !== undefined) {
    config.basePath = options.basePath;
  }

  return config;
}

/**
 * Creates configuration for internal API (VPC-only access)
 * This would typically be used with VPC endpoints
 */
export function createInternalApiConfig(
  options: {
    allowedSourceIps?: string[];
    cors?: boolean;
    basePath?: string;
  } = {}
): ApiConfig {
  const config: ApiConfig = {
    cors: options.cors ?? false, // Internal APIs typically don't need CORS
    auth: {
      type: 'custom',
      validator: async (event: APIGatewayProxyEvent): Promise<boolean> => {
        // Check source IP if configured
        if (options.allowedSourceIps && options.allowedSourceIps.length > 0) {
          const sourceIp = event.requestContext.identity.sourceIp;
          return options.allowedSourceIps.includes(sourceIp);
        }

        // For internal APIs, we might check VPC source or other internal identifiers
        // This is a simplified example
        const userAgent = event.headers['User-Agent'] || event.headers['user-agent'] || '';
        return userAgent.includes('internal-service') || userAgent.includes('aws-internal');
      },
    },
  };

  if (options.basePath !== undefined) {
    config.basePath = options.basePath;
  }

  return config;
}

/**
 * Utility function to extract JWT payload (mock implementation)
 * In a real application, use a proper JWT library like jsonwebtoken
 */
export function extractJwtPayload(token: string): JwtPayload | null {
  try {
    // This is a mock implementation
    // In production, use a proper JWT library to decode and validate the token
    const parts = token.split('.');
    if (parts.length !== 3) {
      return null;
    }

    const payload = parts[1];
    if (!payload) {
      return null;
    }

    const decoded = Buffer.from(payload, 'base64url').toString('utf8');
    return JSON.parse(decoded) as JwtPayload;
  } catch (error) {
    return null;
  }
}

/**
 * Utility function to validate JWT token structure
 */
export function isValidJwtStructure(token: string): boolean {
  const parts = token.split('.');
  return parts.length === 3 && parts.every(part => part.length > 0);
}
