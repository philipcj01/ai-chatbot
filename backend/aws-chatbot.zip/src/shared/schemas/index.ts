import { z } from 'zod';
import { CommonSchemas, SchemaTransforms } from '@shared/utils/validation';

/**
 * User-related schemas
 */
export const UserSchemas = {
  // Create user request
  createUser: z.object({
    name: SchemaTransforms.trim.pipe(
      z.string().min(1, 'Name is required').max(100, 'Name cannot exceed 100 characters')
    ),
    email: SchemaTransforms.trim.pipe(SchemaTransforms.toLowerCase.pipe(CommonSchemas.email)),
  }),

  // Update user request
  updateUser: z
    .object({
      name: SchemaTransforms.trim
        .pipe(
          z.string().min(1, 'Name cannot be empty').max(100, 'Name cannot exceed 100 characters')
        )
        .optional(),
      email: SchemaTransforms.trim
        .pipe(SchemaTransforms.toLowerCase.pipe(CommonSchemas.email))
        .optional(),
    })
    .refine(
      data => data.name !== undefined || data.email !== undefined,
      'At least one field (name or email) must be provided'
    ),

  // Path parameters
  userPathParams: z.object({
    id: CommonSchemas.id,
  }),

  // Query parameters for user search
  userSearchQuery: z.object({
    q: z
      .string()
      .min(1, 'Search query is required')
      .max(200, 'Search query too long')
      .transform(val => val.trim()),
  }),

  // Query parameters for user list
  userListQuery: CommonSchemas.pagination.extend({
    search: z.string().optional(),
    sortBy: z.enum(['name', 'email', 'createdAt', 'updatedAt']).default('createdAt'),
    sortOrder: z.enum(['asc', 'desc']).default('desc'),
  }),
};

/**
 * Hello API schemas
 */
export const HelloSchemas = {
  // Hello request body
  helloRequest: z.object({
    name: SchemaTransforms.trim
      .pipe(z.string().min(1, 'Name cannot be empty').max(50, 'Name too long'))
      .optional(),
  }),

  // Hello path parameters
  helloPathParams: z.object({
    name: SchemaTransforms.trim.pipe(
      z.string().min(1, 'Name cannot be empty').max(50, 'Name too long')
    ),
  }),

  // Hello query parameters
  helloQueryParams: z.object({
    name: SchemaTransforms.trim
      .pipe(z.string().min(1, 'Name cannot be empty').max(50, 'Name too long'))
      .optional(),
  }),
};

/**
 * Admin API schemas
 */
export const AdminSchemas = {
  // Admin stats query parameters
  adminStatsQuery: z.object({
    days: z.coerce
      .number()
      .int()
      .min(1, 'Days must be at least 1')
      .max(365, 'Days cannot exceed 365')
      .default(30),
    includeInactive: z.coerce.boolean().default(false),
  }),

  // Admin user list query
  adminUserQuery: CommonSchemas.pagination.extend({
    status: z.enum(['active', 'inactive', 'all']).default('all'),
    sortBy: z.enum(['name', 'email', 'createdAt', 'updatedAt']).default('createdAt'),
    sortOrder: z.enum(['asc', 'desc']).default('desc'),
  }),

  // Force delete user parameters
  forceDeleteParams: z.object({
    id: CommonSchemas.id,
    reason: z
      .string()
      .min(10, 'Deletion reason must be at least 10 characters')
      .max(500, 'Deletion reason too long')
      .optional(),
  }),
};

/**
 * Common API schemas
 */
export const CommonApiSchemas = {
  // Standard ID path parameter
  idPathParams: z.object({
    id: CommonSchemas.id,
  }),

  // Health check response
  healthCheck: z.object({
    status: z.enum(['healthy', 'unhealthy', 'degraded']),
    timestamp: z.string().datetime(),
    version: z.string(),
    environment: CommonSchemas.environment,
    services: z.record(z.enum(['operational', 'degraded', 'down'])),
  }),

  // Error response
  errorResponse: z.object({
    error: z.string(),
    message: z.string(),
    timestamp: z.string().datetime(),
    requestId: z.string().optional(),
    details: z
      .array(
        z.object({
          field: z.string(),
          message: z.string(),
          code: z.string(),
        })
      )
      .optional(),
  }),

  // Success response wrapper
  successResponse: z.object({
    success: z.literal(true),
    data: z.any(),
    timestamp: z.string().datetime(),
    requestId: z.string().optional(),
  }),
};

/**
 * JWT payload schemas
 */
export const AuthSchemas = {
  // JWT payload
  jwtPayload: z.object({
    sub: z.string().min(1, 'Subject is required'),
    aud: z.string().min(1, 'Audience is required'),
    iss: z.string().min(1, 'Issuer is required'),
    exp: z.number().int().positive('Expiration must be positive'),
    iat: z.number().int().positive('Issued at must be positive'),
    roles: z.array(z.string()).default([]),
    permissions: z.array(z.string()).default([]),
    userId: z.string().optional(),
    email: CommonSchemas.email.optional(),
  }),

  // API key validation
  apiKeyHeader: z
    .object({
      'x-api-key': z
        .string()
        .min(32, 'API key too short')
        .max(128, 'API key too long')
        .regex(/^[a-zA-Z0-9-_]+$/, 'Invalid API key format'),
    })
    .or(
      z.object({
        'X-API-Key': z
          .string()
          .min(32, 'API key too short')
          .max(128, 'API key too long')
          .regex(/^[a-zA-Z0-9-_]+$/, 'Invalid API key format'),
      })
    ),
};

/**
 * Database entity schemas
 */
export const EntitySchemas = {
  // Base entity
  baseEntity: z.object({
    id: CommonSchemas.id,
    createdAt: z.string().datetime(),
    updatedAt: z.string().datetime(),
  }),

  // User entity
  userEntity: z.object({
    id: CommonSchemas.id,
    name: z.string().min(1).max(100),
    email: CommonSchemas.email,
    createdAt: z.string().datetime(),
    updatedAt: z.string().datetime(),
    status: z.enum(['active', 'inactive', 'suspended']).default('active'),
  }),

  // User statistics
  userStats: z.object({
    totalUsers: z.number().int().min(0),
    recentUsers: z.array(z.any()),
    activeUsers: z.number().int().min(0).optional(),
    inactiveUsers: z.number().int().min(0).optional(),
  }),
};
