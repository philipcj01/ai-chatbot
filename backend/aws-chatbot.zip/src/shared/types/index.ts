import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';

// Common response interface
export interface LambdaResponse {
  statusCode: number;
  headers?: Record<string, string>;
  body: string;
  isBase64Encoded?: boolean;
}

// API Gateway Lambda handler type
export type APIGatewayHandler = (
  event: APIGatewayProxyEvent,
  context: Context
) => Promise<APIGatewayProxyResult>;

// Generic Lambda handler type
export type LambdaHandler<TEvent = any, TResult = any> = (
  event: TEvent,
  context: Context
) => Promise<TResult>;

// Common error response
export interface ErrorResponse {
  error: string;
  message: string;
  requestId?: string;
  timestamp: string;
}

// Success response wrapper
export interface SuccessResponse<T = any> {
  success: true;
  data: T;
  requestId?: string;
  timestamp: string;
}

// DynamoDB item interface (generic)
export interface DynamoDBItem {
  [key: string]: any;
}

// S3 event types
export interface S3EventRecord {
  eventVersion: string;
  eventSource: string;
  eventTime: string;
  eventName: string;
  s3: {
    bucket: {
      name: string;
    };
    object: {
      key: string;
      size: number;
    };
  };
}

// SQS message interface
export interface SQSMessageBody {
  [key: string]: any;
}

// Environment variables interface
export interface Environment {
  AWS_REGION: string;
  TABLE_NAME?: string;
  BUCKET_NAME?: string;
  QUEUE_URL?: string;
  TOPIC_ARN?: string;
}
