import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
import { createErrorResponse } from '@shared/utils/response';
import { createLogger } from '@shared/utils/logger';

export interface LambdaMiddleware {
  before?: (event: APIGatewayProxyEvent, context: Context) => Promise<void>;
  after?: (
    event: APIGatewayProxyEvent,
    context: Context,
    response: APIGatewayProxyResult
  ) => Promise<APIGatewayProxyResult>;
  onError?: (
    error: Error,
    event: APIGatewayProxyEvent,
    context: Context
  ) => Promise<APIGatewayProxyResult>;
}

/**
 * Wraps a Lambda handler with middleware for error handling, logging, and validation
 */
export const withMiddleware = (
  handler: (event: APIGatewayProxyEvent, context: Context) => Promise<APIGatewayProxyResult>,
  middleware: LambdaMiddleware = {}
) => {
  return async (event: APIGatewayProxyEvent, context: Context): Promise<APIGatewayProxyResult> => {
    const logger = createLogger(context);

    try {
      logger.info('Lambda function started', {
        httpMethod: event.httpMethod,
        path: event.path,
        requestId: context.awsRequestId,
      });

      // Execute before middleware
      if (middleware.before) {
        await middleware.before(event, context);
      }

      // Execute main handler
      let response = await handler(event, context);

      // Execute after middleware
      if (middleware.after) {
        response = await middleware.after(event, context, response);
      }

      logger.info('Lambda function completed successfully', {
        statusCode: response.statusCode,
        requestId: context.awsRequestId,
      });

      return response;
    } catch (error) {
      logger.error('Lambda function failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        stack: error instanceof Error ? error.stack : undefined,
        requestId: context.awsRequestId,
      });

      // Execute error middleware if provided
      if (middleware.onError) {
        return await middleware.onError(error as Error, event, context);
      }

      // Default error response
      return createErrorResponse(
        'InternalServerError',
        error instanceof Error ? error.message : 'An unexpected error occurred',
        500
      );
    }
  };
};

/**
 * Validation middleware to check required parameters
 */
export const validateRequiredFields = (requiredFields: string[]) => ({
  before: async (event: APIGatewayProxyEvent): Promise<void> => {
    const body = event.body ? JSON.parse(event.body) : {};
    const missing = requiredFields.filter(field => !body[field]);

    if (missing.length > 0) {
      throw new Error(`Missing required fields: ${missing.join(', ')}`);
    }
  },
});

/**
 * CORS middleware
 */
export const corsMiddleware = {
  after: async (
    _event: APIGatewayProxyEvent,
    _context: Context,
    response: APIGatewayProxyResult
  ): Promise<APIGatewayProxyResult> => {
    return {
      ...response,
      headers: {
        ...response.headers,
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers':
          'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      },
    };
  },
};
