import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
import { createLogger, Logger } from '@shared/utils/logger';
import {
  createErrorResponse,
  createCorsResponse,
} from '@shared/utils/response';
import { ValidationError, NotFoundError, UnauthorizedError } from '@shared/utils/errors';

export interface RouteHandler {
  method: string;
  path: string;
  handler: (
    event: APIGatewayProxyEvent,
    context: Context,
    pathParams: Record<string, string>
  ) => Promise<APIGatewayProxyResult>;
  requiresAuth?: boolean;
  validation?: {
    body?: Record<string, any>;
    query?: string[];
    path?: string[];
  };
}

export interface ApiConfig {
  basePath?: string;
  cors?: boolean;
  auth?: {
    type: 'jwt' | 'api-key' | 'custom';
    validator?: (event: APIGatewayProxyEvent) => Promise<boolean>;
  };
}

export abstract class BaseApiHandler {
  protected logger: Logger;
  protected config: ApiConfig;
  protected routes: RouteHandler[] = [];

  constructor(config: ApiConfig = {}) {
    this.config = {
      cors: true,
      ...config,
    };
    this.logger = createLogger();
  }

  /**
   * Register a route handler
   */
  protected registerRoute(route: RouteHandler): void {
    this.routes.push(route);
  }

  /**
   * Register multiple routes
   */
  protected registerRoutes(routes: RouteHandler[]): void {
    this.routes.push(...routes);
  }

  /**
   * Main handler function that processes incoming requests
   */
  public async handle(
    event: APIGatewayProxyEvent,
    context: Context
  ): Promise<APIGatewayProxyResult> {
    this.logger = createLogger(context);

    try {
      this.logger.info('API request received', {
        method: event.httpMethod,
        path: event.path,
        requestId: context.awsRequestId,
      });

      // Handle CORS preflight
      if (event.httpMethod === 'OPTIONS') {
        return this.handleCorsPrelight();
      }

      // Find matching route
      const route = this.findMatchingRoute(event);
      if (!route) {
        return this.handleNotFound();
      }

      // Extract path parameters
      const pathParams = this.extractPathParams(event.path, route.path);

      // Validate request
      await this.validateRequest(event, route);

      // Check authentication if required
      if (route.requiresAuth && this.config.auth) {
        const isAuthorized = await this.authenticateRequest(event);
        if (!isAuthorized) {
          return createErrorResponse('Unauthorized', 'Access denied', 401);
        }
      }

      // Execute route handler
      const response = await route.handler(event, context, pathParams);

      // Apply CORS headers if enabled
      if (this.config.cors) {
        return this.applyCorsHeaders(response);
      }

      return response;
    } catch (error) {
      return this.handleError(error, event, context);
    }
  }

  /**
   * Find matching route based on method and path
   */
  private findMatchingRoute(event: APIGatewayProxyEvent): RouteHandler | undefined {
    const { httpMethod, path } = event;

    return this.routes.find(route => {
      if (route.method !== httpMethod) return false;
      return this.matchPath(path, route.path);
    });
  }

  /**
   * Match path with route pattern (supports path parameters)
   */
  private matchPath(requestPath: string, routePath: string): boolean {
    const requestSegments = requestPath.split('/').filter(Boolean);
    const routeSegments = routePath.split('/').filter(Boolean);

    if (requestSegments.length !== routeSegments.length) return false;

    return routeSegments.every((segment, index) => {
      return (
        (segment.startsWith('{') && segment.endsWith('}')) || segment === requestSegments[index]
      );
    });
  }

  /**
   * Extract path parameters from request path
   */
  private extractPathParams(requestPath: string, routePath: string): Record<string, string> {
    const requestSegments = requestPath.split('/').filter(Boolean);
    const routeSegments = routePath.split('/').filter(Boolean);
    const params: Record<string, string> = {};

    routeSegments.forEach((segment, index) => {
      if (segment.startsWith('{') && segment.endsWith('}')) {
        const paramName = segment.slice(1, -1);
        const paramValue = requestSegments[index];
        if (paramValue) {
          params[paramName] = paramValue;
        }
      }
    });

    return params;
  }

  /**
   * Validate request based on route configuration
   */
  private async validateRequest(event: APIGatewayProxyEvent, route: RouteHandler): Promise<void> {
    if (!route.validation) return;

    const { body: bodySchema, query: queryFields, path: pathFields } = route.validation;

    // Validate request body
    if (bodySchema && event.body) {
      try {
        const body = JSON.parse(event.body);
        // Simple validation - check required fields
        const requiredFields = Object.keys(bodySchema);
        const missingFields = requiredFields.filter(field => !body[field]);
        if (missingFields.length > 0) {
          throw new ValidationError(`Missing required fields: ${missingFields.join(', ')}`);
        }
      } catch (error) {
        if (error instanceof SyntaxError) {
          throw new ValidationError('Invalid JSON in request body');
        }
        throw error;
      }
    }

    // Validate query parameters
    if (queryFields && queryFields.length > 0) {
      const missingQuery = queryFields.filter(
        field => !event.queryStringParameters || !event.queryStringParameters[field]
      );
      if (missingQuery.length > 0) {
        throw new ValidationError(`Missing required query parameters: ${missingQuery.join(', ')}`);
      }
    }

    // Validate path parameters
    if (pathFields && pathFields.length > 0) {
      const missingPath = pathFields.filter(
        field => !event.pathParameters || !event.pathParameters[field]
      );
      if (missingPath.length > 0) {
        throw new ValidationError(`Missing required path parameters: ${missingPath.join(', ')}`);
      }
    }
  }

  /**
   * Authenticate request
   */
  private async authenticateRequest(event: APIGatewayProxyEvent): Promise<boolean> {
    if (!this.config.auth?.validator) return true;

    try {
      return await this.config.auth.validator(event);
    } catch (error) {
      this.logger.error('Authentication error', {
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      return false;
    }
  }

  /**
   * Handle CORS preflight requests
   */
  private handleCorsPrelight(): APIGatewayProxyResult {
    return createCorsResponse();
  }

  /**
   * Handle 404 Not Found
   */
  private handleNotFound(): APIGatewayProxyResult {
    return createErrorResponse('NotFound', 'Endpoint not found', 404);
  }

  /**
   * Apply CORS headers to response
   */
  private applyCorsHeaders(response: APIGatewayProxyResult): APIGatewayProxyResult {
    return {
      ...response,
      headers: {
        ...response.headers,
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers':
          'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      },
    };
  }

  /**
   * Handle errors and return appropriate responses
   */
  private handleError(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    error: any,
    event: APIGatewayProxyEvent,
    context: Context
  ): APIGatewayProxyResult {
    this.logger.error('API request failed', {
      error: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined,
      method: event.httpMethod,
      path: event.path,
      requestId: context.awsRequestId,
    });

    if (error instanceof ValidationError) {
      return createErrorResponse('ValidationError', error.message, 400);
    }

    if (error instanceof NotFoundError) {
      return createErrorResponse('NotFound', error.message, 404);
    }

    if (error instanceof UnauthorizedError) {
      return createErrorResponse('Unauthorized', error.message, 401);
    }

    return createErrorResponse('InternalServerError', 'An unexpected error occurred', 500);
  }

  /**
   * Abstract method for child classes to define their routes
   */
  protected abstract defineRoutes(): void;
}
