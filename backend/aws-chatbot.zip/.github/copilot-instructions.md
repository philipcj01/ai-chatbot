<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# AWS Lambda TypeScript Project

This is an AWS Lambda TypeScript project with the following structure and conventions:

## Project Structure

- `src/functions/` - Contains individual Lambda function handlers
- `src/shared/` - Contains shared utilities, types, and middleware
- `tests/` - Contains unit and integration tests
- `build/` - Compiled TypeScript output (auto-generated)

## Coding Standards

- Use TypeScript with strict type checking
- Follow functional programming patterns where possible
- Use async/await for asynchronous operations
- Implement proper error handling with structured logging
- Use middleware pattern for cross-cutting concerns (CORS, validation, error handling)

## AWS Services Integration

- Use AWS SDK v3 for all AWS service interactions
- Implement DynamoDB operations with proper error handling
- Use structured logging for CloudWatch integration
- Follow AWS Lambda best practices for performance and security

## Testing Guidelines

- Write unit tests for all Lambda functions
- Mock AWS services in tests
- Use Jest for testing framework
- Maintain high test coverage

## Deployment

- Use AWS SAM for infrastructure as code
- Environment-specific configurations
- Proper IAM permissions and security practices
