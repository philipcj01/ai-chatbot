// Global test setup
process.env.NODE_ENV = 'test';
process.env.AWS_REGION = 'us-east-1';
process.env.TABLE_NAME = 'test-users';

// Mock AWS SDK
jest.mock('@aws-sdk/client-dynamodb');
jest.mock('@aws-sdk/lib-dynamodb');

// Silence console.log in tests unless explicitly needed
global.console = {
  ...console,
  log: jest.fn(),
  debug: jest.fn(),
  info: jest.fn(),
  warn: jest.fn(),
  error: jest.fn(),
};
