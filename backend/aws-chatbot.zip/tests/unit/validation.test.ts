import { z } from 'zod';
import {
  validateSchema,
  validateSchemaSync,
  validateEventBody,
  validateQueryParams,
  validatePathParams,
  createValidationMiddleware,
  CommonSchemas,
  SchemaTransforms,
} from '../../src/shared/utils/validation';
import { ValidationError } from '../../src/shared/utils/errors';

describe('Zod Validation Utilities', () => {
  // Mock console methods to avoid noise in tests
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('validateSchema', () => {
    const testSchema = z.object({
      name: z.string().min(1),
      age: z.number().int().min(0),
      email: z.string().email(),
    });

    it('should validate valid data successfully', async () => {
      const validData = {
        name: 'John Doe',
        age: 30,
        email: 'john@example.com',
      };

      const result = await validateSchema(testSchema, validData);

      expect(result.success).toBe(true);
      expect(result.data).toEqual(validData);
      expect(result.errors).toBeUndefined();
    });

    it('should return validation errors for invalid data', async () => {
      const invalidData = {
        name: '',
        age: -5,
        email: 'invalid-email',
      };

      const result = await validateSchema(testSchema, invalidData, { throwOnError: false });

      expect(result.success).toBe(false);
      expect(result.data).toBeUndefined();
      expect(result.errors).toBeDefined();
      expect(result.errors).toHaveLength(3);
      expect(result.errors?.[0].field).toBe('name');
      expect(result.errors?.[1].field).toBe('age');
      expect(result.errors?.[2].field).toBe('email');
    });

    it('should throw ValidationError when throwOnError is true', async () => {
      const invalidData = { name: '', age: -5 };

      await expect(validateSchema(testSchema, invalidData, { throwOnError: true })).rejects.toThrow(
        ValidationError
      );
    });

    it('should handle unknown fields when stripUnknown is true', async () => {
      const dataWithExtra = {
        name: 'John',
        age: 30,
        email: 'john@example.com',
        extraField: 'should be removed',
      };

      const result = await validateSchema(testSchema, dataWithExtra, { stripUnknown: true });

      expect(result.success).toBe(false); // strict mode rejects unknown fields
    });
  });

  describe('validateSchemaSync', () => {
    const simpleSchema = z.object({
      value: z.string(),
    });

    it('should validate synchronously', () => {
      const result = validateSchemaSync(simpleSchema, { value: 'test' });

      expect(result.success).toBe(true);
      expect(result.data).toEqual({ value: 'test' });
    });

    it('should handle sync validation errors', () => {
      const result = validateSchemaSync(simpleSchema, { value: 123 });

      expect(result.success).toBe(false);
      expect(result.errors).toBeDefined();
    });
  });

  describe('validateEventBody', () => {
    const bodySchema = z.object({
      username: z.string().min(3),
      password: z.string().min(8),
    });

    it('should validate valid JSON body', async () => {
      const body = JSON.stringify({
        username: 'testuser',
        password: 'password123',
      });

      const result = await validateEventBody(bodySchema, body);

      expect(result.success).toBe(true);
      expect(result.data?.username).toBe('testuser');
    });

    it('should handle null body', async () => {
      const result = await validateEventBody(bodySchema, null, { throwOnError: false });

      expect(result.success).toBe(false);
      expect(result.errors?.[0].field).toBe('body');
      expect(result.errors?.[0].message).toBe('Request body is required');
    });

    it('should handle invalid JSON', async () => {
      const result = await validateEventBody(bodySchema, 'invalid json', { throwOnError: false });

      expect(result.success).toBe(false);
      expect(result.errors?.[0].code).toBe('invalid_json');
    });

    it('should throw when body is required and throwOnError is true', async () => {
      await expect(validateEventBody(bodySchema, null, { throwOnError: true })).rejects.toThrow(
        'Request body is required'
      );
    });
  });

  describe('validateQueryParams', () => {
    const querySchema = z.object({
      page: z.coerce.number().int().min(1),
      limit: z.coerce.number().int().max(100),
      search: z.string().optional(),
    });

    it('should validate query parameters', async () => {
      const queryParams = {
        page: '2',
        limit: '10',
        search: 'test',
      };

      const result = await validateQueryParams(querySchema, queryParams);

      expect(result.success).toBe(true);
      expect(result.data?.page).toBe(2);
      expect(result.data?.limit).toBe(10);
      expect(result.data?.search).toBe('test');
    });

    it('should handle null query parameters', async () => {
      const result = await validateQueryParams(querySchema, null);

      expect(result.success).toBe(false);
    });
  });

  describe('validatePathParams', () => {
    const pathSchema = z.object({
      id: z.string().uuid(),
      category: z.string().min(1),
    });

    it('should validate path parameters', async () => {
      const pathParams = {
        id: '123e4567-e89b-12d3-a456-426614174000',
        category: 'electronics',
      };

      const result = await validatePathParams(pathSchema, pathParams);

      expect(result.success).toBe(true);
      expect(result.data).toEqual(pathParams);
    });
  });

  describe('createValidationMiddleware', () => {
    const bodySchema = z.object({ name: z.string() });
    const querySchema = z.object({ page: z.coerce.number() });
    const pathSchema = z.object({ id: z.string() });

    it('should create middleware that validates all parameters', async () => {
      const middleware = createValidationMiddleware({
        bodySchema,
        querySchema,
        pathSchema,
      });

      const mockEvent = {
        body: JSON.stringify({ name: 'test' }),
        queryStringParameters: { page: '1' },
        pathParameters: { id: 'test-id' },
      };

      const result = await middleware(mockEvent);

      expect(result.body).toEqual({ name: 'test' });
      expect(result.query).toEqual({ page: 1 });
      expect(result.path).toEqual({ id: 'test-id' });
    });

    it('should throw validation errors when configured', async () => {
      const middleware = createValidationMiddleware({
        bodySchema,
        options: { throwOnError: true },
      });

      const mockEvent = {
        body: JSON.stringify({ name: '' }), // Invalid: empty name
      };

      await expect(middleware(mockEvent)).rejects.toThrow(ValidationError);
    });
  });

  describe('CommonSchemas', () => {
    it('should validate email schema', () => {
      const validEmails = ['test@example.com', 'user+label@domain.co.uk'];
      const invalidEmails = ['invalid', '@domain.com', 'test@'];

      validEmails.forEach(email => {
        const result = CommonSchemas.email.safeParse(email);
        expect(result.success).toBe(true);
      });

      invalidEmails.forEach(email => {
        const result = CommonSchemas.email.safeParse(email);
        expect(result.success).toBe(false);
      });
    });

    it('should validate pagination schema', () => {
      const validPagination = { page: '1', limit: '10' };
      const result = CommonSchemas.pagination.safeParse(validPagination);

      expect(result.success).toBe(true);
      expect(result.data?.page).toBe(1);
      expect(result.data?.limit).toBe(10);
    });

    it('should validate AWS resource name', () => {
      const validNames = ['my-resource', 'resource_123', 'Resource-Name'];
      const invalidNames = ['', 'resource with spaces', 'resource@domain'];

      validNames.forEach(name => {
        const result = CommonSchemas.awsResourceName.safeParse(name);
        expect(result.success).toBe(true);
      });

      invalidNames.forEach(name => {
        const result = CommonSchemas.awsResourceName.safeParse(name);
        expect(result.success).toBe(false);
      });
    });

    it('should validate date range', () => {
      const validRange = {
        startDate: '2023-01-01T00:00:00Z',
        endDate: '2023-12-31T23:59:59Z',
      };

      const result = CommonSchemas.dateRange.safeParse(validRange);
      expect(result.success).toBe(true);

      const invalidRange = {
        startDate: '2023-12-31T00:00:00Z',
        endDate: '2023-01-01T00:00:00Z',
      };

      const invalidResult = CommonSchemas.dateRange.safeParse(invalidRange);
      expect(invalidResult.success).toBe(false);
    });
  });

  describe('SchemaTransforms', () => {
    it('should transform to lowercase', () => {
      const result = SchemaTransforms.toLowerCase.parse('HELLO WORLD');
      expect(result).toBe('hello world');
    });

    it('should transform to uppercase', () => {
      const result = SchemaTransforms.toUpperCase.parse('hello world');
      expect(result).toBe('HELLO WORLD');
    });

    it('should trim whitespace', () => {
      const result = SchemaTransforms.trim.parse('  hello world  ');
      expect(result).toBe('hello world');
    });

    it('should parse JSON', () => {
      const jsonString = '{"key": "value"}';
      const result = SchemaTransforms.parseJson.parse(jsonString);
      expect(result).toEqual({ key: 'value' });
    });

    it('should handle invalid JSON in parseJson', () => {
      const result = SchemaTransforms.parseJson.safeParse('invalid json');
      expect(result.success).toBe(false);
    });

    it('should parse CSV', () => {
      const csvString = 'apple, banana, cherry, ';
      const result = SchemaTransforms.parseCsv.parse(csvString);
      expect(result).toEqual(['apple', 'banana', 'cherry']);
    });
  });
});
