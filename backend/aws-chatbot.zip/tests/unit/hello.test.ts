import { APIGatewayProxyEvent, Context } from 'aws-lambda';
import { handler } from '../../src/functions/hello';

describe('Hello Lambda Function', () => {
  const mockContext: Context = {
    callbackWaitsForEmptyEventLoop: false,
    functionName: 'test-hello',
    functionVersion: '$LATEST',
    invokedFunctionArn: 'arn:aws:lambda:us-east-1:123456789012:function:test-hello',
    memoryLimitInMB: '256',
    awsRequestId: 'test-request-id',
    logGroupName: '/aws/lambda/test-hello',
    logStreamName: '2023/01/01/[$LATEST]test',
    getRemainingTimeInMillis: () => 30000,
    done: jest.fn(),
    fail: jest.fn(),
    succeed: jest.fn(),
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should return hello world with default name', async () => {
    const event: Partial<APIGatewayProxyEvent> = {
      httpMethod: 'GET',
      path: '/hello',
      queryStringParameters: null,
      pathParameters: null,
      body: null,
      headers: {},
      isBase64Encoded: false,
    };

    const result = await handler(event as APIGatewayProxyEvent, mockContext);

    expect(result.statusCode).toBe(200);

    const body = JSON.parse(result.body);
    expect(body.success).toBe(true);
    expect(body.data.message).toBe('Hello, World!');
    expect(body.data.requestId).toBe('test-request-id');
  });

  it('should return hello with name from query parameters', async () => {
    const event: Partial<APIGatewayProxyEvent> = {
      httpMethod: 'GET',
      path: '/hello',
      queryStringParameters: { name: 'John' },
      pathParameters: null,
      body: null,
      headers: {},
      isBase64Encoded: false,
    };

    const result = await handler(event as APIGatewayProxyEvent, mockContext);

    expect(result.statusCode).toBe(200);

    const body = JSON.parse(result.body);
    expect(body.success).toBe(true);
    expect(body.data.message).toBe('Hello, John!');
  });

  it('should return hello with name from path parameters', async () => {
    const event: Partial<APIGatewayProxyEvent> = {
      httpMethod: 'GET',
      path: '/hello/Jane',
      queryStringParameters: null,
      pathParameters: { name: 'Jane' },
      body: null,
      headers: {},
      isBase64Encoded: false,
    };

    const result = await handler(event as APIGatewayProxyEvent, mockContext);

    expect(result.statusCode).toBe(200);

    const body = JSON.parse(result.body);
    expect(body.success).toBe(true);
    expect(body.data.message).toBe('Hello, Jane!');
  });

  it('should return hello with name from POST body', async () => {
    const event: Partial<APIGatewayProxyEvent> = {
      httpMethod: 'POST',
      path: '/hello',
      queryStringParameters: null,
      pathParameters: null,
      body: JSON.stringify({ name: 'Alice' }),
      headers: { 'Content-Type': 'application/json' },
      isBase64Encoded: false,
    };

    const result = await handler(event as APIGatewayProxyEvent, mockContext);

    expect(result.statusCode).toBe(200);

    const body = JSON.parse(result.body);
    expect(body.success).toBe(true);
    expect(body.data.message).toBe('Hello, Alice!');
  });

  it('should handle CORS preflight request', async () => {
    const event: Partial<APIGatewayProxyEvent> = {
      httpMethod: 'OPTIONS',
      path: '/hello',
      queryStringParameters: null,
      pathParameters: null,
      body: null,
      headers: {},
      isBase64Encoded: false,
    };

    const result = await handler(event as APIGatewayProxyEvent, mockContext);

    expect(result.statusCode).toBe(200);
    expect(result.headers?.['Access-Control-Allow-Origin']).toBe('*');
    expect(result.headers?.['Access-Control-Allow-Methods']).toBe('GET,POST,PUT,DELETE,OPTIONS');
  });

  it('should handle invalid JSON in body gracefully', async () => {
    const event: Partial<APIGatewayProxyEvent> = {
      httpMethod: 'POST',
      path: '/hello',
      queryStringParameters: null,
      pathParameters: null,
      body: 'invalid json',
      headers: { 'Content-Type': 'application/json' },
      isBase64Encoded: false,
    };

    const result = await handler(event as APIGatewayProxyEvent, mockContext);

    expect(result.statusCode).toBe(400);

    const body = JSON.parse(result.body);
    expect(body.error).toBe('BadRequest');
  });
});
