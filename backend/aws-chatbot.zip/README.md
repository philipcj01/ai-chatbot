# AWS Lambda TypeScript API Framework

A production-ready, well-structured AWS Lambda TypeScript framework with base handlers, generic API configurations, and comprehensive tooling for building REST APIs at scale.

## 🏗️ Enhanced Architecture

The framework now provides a robust foundation for building scalable REST APIs with:

- **BaseApiHandler**: Generic Lambda handler that functions can extend
- **BaseService**: Generic service layer for data operations
- **API Configuration Utilities**: Easy creation of public/private APIs
- **Built-in Authentication**: JWT, API Key, and custom auth support
- **Advanced Routing**: Pattern matching with path parameters
- **Comprehensive Error Handling**: Custom error classes and structured responses

### Project Structure

```
├── src/
│   ├── functions/                  # Lambda function handlers
│   │   ├── hello/                 # Public API example
│   │   ├── users/                 # Public CRUD API
│   │   └── admin/                 # Private JWT-protected API
│   └── shared/                    # Shared utilities and framework
│       ├── handlers/              # Base handler classes
│       │   └── base-api-handler.ts
│       ├── services/              # Service layer
│       │   ├── base-service.ts
│       │   └── user-service.ts
│       ├── utils/                 # Utilities
│       │   ├── api-config.ts      # API configuration helpers
│       │   ├── errors.ts          # Custom error classes
│       │   ├── logger.ts          # Structured logging
│       │   ├── response.ts        # Response utilities
│       │   └── dynamodb.ts        # DynamoDB wrapper
│       └── types/                 # TypeScript definitions
├── tests/                         # Test suites
└── template.yaml                  # AWS SAM template
```

## 🚀 Quick Start

### 1. Create a New Lambda Function

```typescript
// src/functions/my-api/index.ts
import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
import { BaseApiHandler, RouteHandler } from '@shared/handlers/base-api-handler';
import { createPublicApiConfig } from '@shared/utils/api-config';
import { createSuccessResponse } from '@shared/utils/response';

class MyApiHandler extends BaseApiHandler {
  constructor() {
    super(createPublicApiConfig()); // or createPrivateJwtApiConfig()
    this.defineRoutes();
  }

  protected defineRoutes(): void {
    const routes: RouteHandler[] = [
      {
        method: 'GET',
        path: '/my-api/items',
        handler: this.getItems.bind(this),
      },
      {
        method: 'GET',
        path: '/my-api/items/{id}',
        handler: this.getItemById.bind(this),
        validation: {
          path: ['id'],
        },
      },
    ];
    this.registerRoutes(routes);
  }

  private async getItems(
    event: APIGatewayProxyEvent,
    context: Context,
    pathParams: Record<string, string>
  ): Promise<APIGatewayProxyResult> {
    const items = [{ id: '1', name: 'Item 1' }];
    return createSuccessResponse(items);
  }

  private async getItemById(
    event: APIGatewayProxyEvent,
    context: Context,
    pathParams: Record<string, string>
  ): Promise<APIGatewayProxyResult> {
    const { id } = pathParams;
    const item = { id, name: `Item ${id}` };
    return createSuccessResponse(item);
  }
}

const myApiHandler = new MyApiHandler();
export const handler = (event: APIGatewayProxyEvent, context: Context) =>
  myApiHandler.handle(event, context);
```

### 2. Create a Service Layer

```typescript
// src/shared/services/item-service.ts
import { BaseService, BaseEntity } from '@shared/services/base-service';
import { ValidationError } from '@shared/utils/errors';

export interface Item extends BaseEntity {
  name: string;
  category: string;
}

export class ItemService extends BaseService<Item> {
  constructor(tableName: string) {
    super({ tableName });
  }

  protected getEntityType(): string {
    return 'Item';
  }

  protected async validateEntity(item: Item): Promise<void> {
    if (!item.name || item.name.trim().length === 0) {
      throw new ValidationError('Item name is required');
    }
  }

  // Implement other abstract methods...
  protected async validateUpdates(): Promise<void> {}
  protected async checkCreateConflicts(): Promise<void> {}
  protected async checkUpdateConflicts(): Promise<void> {}
  protected async checkDeleteConstraints(): Promise<void> {}
}
```

## 🔐 API Configuration Types

### Public API (No Authentication)

```typescript
import { createPublicApiConfig } from '@shared/utils/api-config';

const config = createPublicApiConfig({
  cors: true,
  basePath: '/api/v1',
});
```

### Private API with JWT

```typescript
import { createPrivateJwtApiConfig } from '@shared/utils/api-config';

const config = createPrivateJwtApiConfig({
  jwtIssuer: 'your-auth-service',
  jwtAudience: 'your-api',
  customValidator: async payload => {
    // Custom role validation
    return payload.roles?.includes('admin');
  },
});
```

### Private API with API Key

```typescript
import { createPrivateApiKeyConfig } from '@shared/utils/api-config';

const config = createPrivateApiKeyConfig({
  apiKeyConfig: {
    headerName: 'X-API-Key',
    validateFunction: async key => {
      // Validate against your key store
      return await validateApiKey(key);
    },
  },
});
```

### Internal API (VPC-only)

```typescript
import { createInternalApiConfig } from '@shared/utils/api-config';

const config = createInternalApiConfig({
  allowedSourceIps: ['10.0.0.0/8'],
  cors: false,
});
```

## 📋 Available Routes

### Public APIs

| Method   | Path                      | Description     |
| -------- | ------------------------- | --------------- |
| GET/POST | `/hello[/{name}]`         | Hello World API |
| GET      | `/hello/health`           | Health check    |
| GET      | `/users`                  | List all users  |
| GET      | `/users/{id}`             | Get user by ID  |
| POST     | `/users`                  | Create new user |
| PUT      | `/users/{id}`             | Update user     |
| DELETE   | `/users/{id}`             | Delete user     |
| GET      | `/users/search?q={query}` | Search users    |
| GET      | `/users/stats`            | User statistics |

### Private APIs (JWT Required)

| Method | Path                | Description       |
| ------ | ------------------- | ----------------- |
| GET    | `/admin/stats`      | Admin statistics  |
| GET    | `/admin/users`      | Admin user view   |
| DELETE | `/admin/users/{id}` | Force delete user |
| GET    | `/admin/health`     | System health     |

## 🛠️ Development

### Install Dependencies

```bash
npm install
```

### Build and Run Locally

```bash
# Build TypeScript
npm run build

# Start local API Gateway
npm run local:start

# Test endpoints
curl http://localhost:3000/hello
curl http://localhost:3000/users
```

### Testing with Authentication

For JWT-protected endpoints, include the Authorization header:

```bash
# Generate a test JWT token (in production, get from your auth service)
curl -H "Authorization: Bearer your-jwt-token" http://localhost:3000/admin/stats
```

### Bundle for Deployment

```bash
# Development bundle with source maps
npm run bundle

# Production bundle (minified)
npm run bundle:prod
```

## 🚢 Deployment

### Deploy with AWS SAM

```bash
# First deployment
npm run deploy:guided

# Subsequent deployments
npm run build && npm run bundle && npm run deploy

# Deploy to production
npm run deploy:prod
```

### Environment Variables

Configure these in your SAM template or Lambda environment:

- `AWS_REGION` - AWS region
- `TABLE_NAME` - DynamoDB table name
- `NODE_ENV` - Environment (development/production/test)

## 🧪 Testing

### Run All Tests

```bash
npm test
```

### Test Coverage

```bash
npm run test:coverage
```

### Create New Tests

```typescript
// tests/unit/my-api.test.ts
import { APIGatewayProxyEvent, Context } from 'aws-lambda';
import { handler } from '../../src/functions/my-api';

describe('My API Function', () => {
  it('should handle GET request', async () => {
    const event: Partial<APIGatewayProxyEvent> = {
      httpMethod: 'GET',
      path: '/my-api/items',
      // ... other properties
    };

    const result = await handler(event as APIGatewayProxyEvent, {} as Context);
    expect(result.statusCode).toBe(200);
  });
});
```

## 📊 Monitoring & Logging

All functions use structured JSON logging for CloudWatch integration:

```json
{
  "timestamp": "2023-10-30T10:00:00.000Z",
  "level": "INFO",
  "message": "API request received",
  "requestId": "abc-123-def",
  "functionName": "my-api",
  "metadata": {
    "method": "GET",
    "path": "/my-api/items"
  }
}
```

## 🔧 Advanced Features

### Custom Error Handling

```typescript
import { ValidationError, NotFoundError } from '@shared/utils/errors';

// Throw custom errors that are automatically handled
throw new ValidationError('Invalid input data');
throw new NotFoundError('Resource not found');
```

### Request Validation

```typescript
{
  method: 'POST',
  path: '/items',
  handler: this.createItem.bind(this),
  validation: {
    body: { name: 'string', category: 'string' }, // Required fields
    query: ['page'], // Required query params
    path: ['id'] // Required path params
  }
}
```

### Service Layer Features

```typescript
const itemService = new ItemService('items-table');

// CRUD operations with built-in validation
const item = await itemService.create({ name: 'New Item', category: 'test' });
const items = await itemService.list({ limit: 10 });
const item = await itemService.getByIdOrThrow('item-123');
await itemService.update('item-123', { name: 'Updated Name' });
await itemService.delete('item-123');

// Custom queries
const items = await itemService.queryByAttribute('category', 'electronics');
```

## 📈 Performance Considerations

- Functions use connection reuse for DynamoDB
- Efficient bundling with esbuild
- Lazy loading of services
- Built-in request validation
- Proper error handling to prevent cold starts

## 🤝 Contributing

1. Follow TypeScript best practices
2. Write comprehensive tests
3. Use the provided linting and formatting tools
4. Update documentation for new features

## 📄 License

ISC License - see LICENSE file for details.
